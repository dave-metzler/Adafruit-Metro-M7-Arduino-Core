# Licenses

The Metro M7 core is licensed **LGPL-2.1-or-later** (see `LICENSE`), except for the third-party
parts below, which keep their own licenses.

| Part | License |
|---|---|
| Core, variant, SPI, Wire, examples, `tools/` (original code) | LGPL-2.1-or-later |
| `cores/imxrt1011/api/` (ArduinoCore-API) | LGPL-2.1-or-later (see `api/ARDUINO_API_LICENSE`) |
| `cores/imxrt1011/imxrt1011.h` (register definitions generated from NXP's SVD) | BSD-3-Clause, (c) NXP |
| `libraries/SD` (Arduino SD 1.3.0, based on Bill Greiman's Sd2Card/SdFile and SparkFun's SD wrapper) | **GPL-3.0** (see `libraries/SD/LICENSE.txt`) |

**Note on the SD library:** it is GPL-3.0, not LGPL.  It is a separate library: a sketch that does not
`#include <SD.h>` is not affected.  A sketch that does link it falls under GPL-3.0 for the combined firmware.
If that is a problem for you, the SD library can be replaced by a permissively licensed one (e.g. SdFat, MIT).
