// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef PINS_ARDUINO_H
#define PINS_ARDUINO_H

#include <stdint.h>

/* Adafruit Metro M7 with microSD (i.MX RT1011).
 * Pad assignments are taken from the board's Eagle schematic
 * (github.com/adafruit/Adafruit-Metro-M7-with-microSD-PCB, CC BY-SA).
 *
 *   Arduino pin   header label   RT1011 pad
 *   D0            RX             GPIO_09   (LPUART1_RXD, ALT0)
 *   D1            TX             GPIO_10   (LPUART1_TXD, ALT0)
 *   D2            D2             GPIO_13
 *   D3            D3             GPIO_12
 *   D4            D4             GPIO_SD_00
 *   D5            D5             GPIO_SD_01
 *   D6            D6             GPIO_SD_02
 *   D7            D7             GPIO_11
 *   D8            D8             GPIO_08
 *   D9            D9             GPIO_07
 *   D10           D10            GPIO_06
 *   D11           D11            GPIO_05
 *   D12           D12            GPIO_04
 *   D13           D13 / LED      GPIO_03
 *   A0            A0             GPIO_AD_02
 *   A1            A1             GPIO_AD_01
 *   A2            A2             GPIO_AD_00
 *   A3            A3             GPIO_AD_05
 *   A4            A4             GPIO_AD_10
 *   A5            A5             GPIO_AD_08
 *   SDA / SCL     STEMMA / hdr   GPIO_01 / GPIO_02  (LPI2C1, ALT3)
 *   MISO/MOSI/SCK SPI header     GPIO_AD_03 / GPIO_AD_04 / GPIO_AD_06 (LPSPI1, ALT0)
 *   SD_CS / SD_CD microSD        GPIO_AD_14 / GPIO_AD_11
 *   NEOPIXEL      WS2812B        GPIO_00
 */

#define PIN_D0   0
#define PIN_D1   1
#define PIN_D2   2
#define PIN_D3   3
#define PIN_D4   4
#define PIN_D5   5
#define PIN_D6   6
#define PIN_D7   7
#define PIN_D8   8
#define PIN_D9   9
#define PIN_D10  10
#define PIN_D11  11
#define PIN_D12  12
#define PIN_D13  13

#define PIN_A0   14
#define PIN_A1   15
#define PIN_A2   16
#define PIN_A3   17
#define PIN_A4   18
#define PIN_A5   19

#define PIN_WIRE_SDA 20
#define PIN_WIRE_SCL 21
#define PIN_SPI_MISO 22
#define PIN_SPI_MOSI 23
#define PIN_SPI_SCK  24
#define PIN_SD_CS    25
#define PIN_SD_CD    26

/* microSD socket sits on the SPI bus above; the SD library picks these up. */
#define SDCARD_SS_PIN PIN_SD_CS
#define SDCARD_SPI    SPI
#define PIN_NEOPIXEL 27

static const uint8_t SDA  = PIN_WIRE_SDA;
static const uint8_t SCL  = PIN_WIRE_SCL;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t SCK  = PIN_SPI_SCK;
static const uint8_t SS   = PIN_SD_CS;

static const uint8_t A0 = PIN_A0;
static const uint8_t A1 = PIN_A1;
static const uint8_t A2 = PIN_A2;
static const uint8_t A3 = PIN_A3;
static const uint8_t A4 = PIN_A4;
static const uint8_t A5 = PIN_A5;

#define LED_BUILTIN PIN_D13
#define NUM_DIGITAL_PINS 28

#endif
