// SPDX-License-Identifier: LGPL-2.1-or-later
#include "Arduino.h"

/* Pin table: mux/pad register addresses come from the SVD-generated header,
 * GPIO controller/bit from NXP's pin-mux header (GPIOMUX_IOnn -> GPIO1 bit nn;
 * GPIO_SD_nn -> GPIO2 bit nn).  Order must match pins_arduino.h. */
#define PIN(pad, gpio, bit) \
    { IOMUXC_SW_MUX_CTL_PAD_##pad##_ADDR, IOMUXC_SW_PAD_CTL_PAD_##pad##_ADDR, gpio, bit }

extern "C" {
const PinDescription g_pinTable[] = {
    PIN(GPIO_09,    1, 9),   /* 0  D0 / RX  */
    PIN(GPIO_10,    1, 10),  /* 1  D1 / TX  */
    PIN(GPIO_13,    1, 13),  /* 2  D2  */
    PIN(GPIO_12,    1, 12),  /* 3  D3  */
    PIN(GPIO_SD_00, 2, 0),   /* 4  D4  */
    PIN(GPIO_SD_01, 2, 1),   /* 5  D5  */
    PIN(GPIO_SD_02, 2, 2),   /* 6  D6  */
    PIN(GPIO_11,    1, 11),  /* 7  D7  */
    PIN(GPIO_08,    1, 8),   /* 8  D8  */
    PIN(GPIO_07,    1, 7),   /* 9  D9  */
    PIN(GPIO_06,    1, 6),   /* 10 D10 */
    PIN(GPIO_05,    1, 5),   /* 11 D11 */
    PIN(GPIO_04,    1, 4),   /* 12 D12 */
    PIN(GPIO_03,    1, 3),   /* 13 D13 / LED */
    PIN(GPIO_AD_02, 1, 16),  /* 14 A0 */
    PIN(GPIO_AD_01, 1, 15),  /* 15 A1 */
    PIN(GPIO_AD_00, 1, 14),  /* 16 A2 */
    PIN(GPIO_AD_05, 1, 19),  /* 17 A3 */
    PIN(GPIO_AD_10, 1, 24),  /* 18 A4 */
    PIN(GPIO_AD_08, 1, 22),  /* 19 A5 */
    PIN(GPIO_01,    1, 1),   /* 20 SDA */
    PIN(GPIO_02,    1, 2),   /* 21 SCL */
    PIN(GPIO_AD_03, 1, 17),  /* 22 MISO */
    PIN(GPIO_AD_04, 1, 18),  /* 23 MOSI */
    PIN(GPIO_AD_06, 1, 20),  /* 24 SCK */
    PIN(GPIO_AD_14, 1, 28),  /* 25 SD_CS */
    PIN(GPIO_AD_11, 1, 25),  /* 26 SD_CD */
    PIN(GPIO_00,    1, 0),   /* 27 NEOPIXEL */
};
/* ADC1 channel number == GPIO_AD_nn pad number (from CircuitPython's RT1011 pin table). */
const uint8_t g_pinAdc[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,   /* D0..D6  */
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,   /* D7..D13 */
    2,    /* 14 A0 = GPIO_AD_02 */
    1,    /* 15 A1 = GPIO_AD_01 */
    0,    /* 16 A2 = GPIO_AD_00 */
    5,    /* 17 A3 = GPIO_AD_05 */
    10,   /* 18 A4 = GPIO_AD_10 */
    8,    /* 19 A5 = GPIO_AD_08 */
    0xFF, 0xFF,                                 /* 20 SDA, 21 SCL */
    0xFF, 0xFF, 0xFF,                           /* 22..24 SPI */
    14,   /* 25 SD_CS = GPIO_AD_14 */
    11,   /* 26 SD_CD = GPIO_AD_11 */
    0xFF, /* 27 NEOPIXEL */
};
#define NOPWM {0xFF, 0, 0, 0}
const PwmDescription g_pinPwm[] = {
    NOPWM, NOPWM, NOPWM, NOPWM, NOPWM,            /* D0..D4 */
    {0, 1, 0, 0x401F8184},                        /* 5  D5  GPIO_SD_01 FLEXPWM1_PWM0_B */
    {0, 0, 0, 0x401F8174},                        /* 6  D6  GPIO_SD_02 FLEXPWM1_PWM0_A */
    NOPWM,                                        /* 7  D7  */
    {3, 0, 1, 0x401F8180},                        /* 8  D8  GPIO_08 FLEXPWM1_PWM3_A */
    {3, 1, 1, 0x401F8190},                        /* 9  D9  GPIO_07 FLEXPWM1_PWM3_B */
    {2, 0, 1, 0x401F817C},                        /* 10 D10 GPIO_06 FLEXPWM1_PWM2_A */
    {2, 1, 1, 0x401F818C},                        /* 11 D11 GPIO_05 FLEXPWM1_PWM2_B */
    {1, 0, 1, 0x401F8178},                        /* 12 D12 GPIO_04 FLEXPWM1_PWM1_A */
    {1, 1, 1, 0x401F8188},                        /* 13 D13 GPIO_03 FLEXPWM1_PWM1_B */
    NOPWM, NOPWM, NOPWM, NOPWM, NOPWM, NOPWM,     /* 14..19 A0..A5 */
    NOPWM, NOPWM, NOPWM, NOPWM, NOPWM, NOPWM, NOPWM, NOPWM,  /* 20..27 */
};
const uint8_t g_pinCount = sizeof(g_pinTable) / sizeof(g_pinTable[0]);
}

/* Serial = native USB CDC; Serial1 = LPUART1 on D0 (RX) / D1 (TX) */
USBSerial Serial;
Uart Serial1;
