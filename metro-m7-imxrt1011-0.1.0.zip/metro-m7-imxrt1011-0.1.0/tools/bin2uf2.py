#!/usr/bin/env python3
"""Convert a raw .bin application image to a UF2 file for TinyUF2 on the Metro M7.

Usage: bin2uf2.py in.bin out.uf2 [base_address]

Defaults match the board's TinyUF2: application base 0x6000C000, NXP RT10xx
family ID 0x4FB2D5BD, 256 bytes of payload per 512-byte block.  These values were
read from Adafruit's own CircuitPython .uf2 for this board (adafruit-circuitpython-
adafruit_metro_m7_1011_sd), and `--selftest` re-packs that image to prove the
packer reproduces Adafruit's file byte for byte.
"""
import struct
import sys

UF2_MAGIC0 = 0x0A324655
UF2_MAGIC1 = 0x9E5D5157
UF2_MAGIC_END = 0x0AB16F30
FLAG_FAMILY_ID = 0x00002000
FAMILY_ID = 0x4FB2D5BD
APP_BASE = 0x6000C000
PAYLOAD = 256


def pack(data: bytes, base: int = APP_BASE) -> bytes:
    nblocks = (len(data) + PAYLOAD - 1) // PAYLOAD
    out = bytearray()
    for i in range(nblocks):
        chunk = data[i * PAYLOAD:(i + 1) * PAYLOAD]
        chunk = chunk + b"\x00" * (476 - len(chunk))  # data area is 476 bytes
        hdr = struct.pack("<8I", UF2_MAGIC0, UF2_MAGIC1, FLAG_FAMILY_ID,
                          base + i * PAYLOAD, PAYLOAD, i, nblocks, FAMILY_ID)
        out += hdr + chunk + struct.pack("<I", UF2_MAGIC_END)
    return bytes(out)


def unpack(uf2: bytes):
    """Return (base_address, image_bytes) for a contiguous UF2."""
    blocks = []
    for i in range(0, len(uf2), 512):
        b = uf2[i:i + 512]
        m0, m1, flags, addr, size, _, _, fam = struct.unpack("<8I", b[:32])
        assert m0 == UF2_MAGIC0 and m1 == UF2_MAGIC1, "bad UF2 block"
        blocks.append((addr, b[32:32 + size]))
    blocks.sort()
    return blocks[0][0], b"".join(x[1] for x in blocks)


def main():
    if len(sys.argv) >= 3 and sys.argv[1] != "--selftest":
        data = open(sys.argv[1], "rb").read()
        base = int(sys.argv[3], 0) if len(sys.argv) > 3 else APP_BASE
        uf2 = pack(data, base)
        open(sys.argv[2], "wb").write(uf2)
        print("wrote %s: %d bytes of image, %d UF2 blocks, base 0x%08X, family 0x%08X"
              % (sys.argv[2], len(data), len(uf2) // 512, base, FAMILY_ID))
    elif len(sys.argv) == 3 and sys.argv[1] == "--selftest":
        ref = open(sys.argv[2], "rb").read()
        base, img = unpack(ref)
        ok = pack(img, base) == ref
        print("selftest: base 0x%08X, %d bytes -> repack %s original"
              % (base, len(img), "IDENTICAL to" if ok else "DIFFERS from"))
        sys.exit(0 if ok else 1)
    else:
        print(__doc__)
        sys.exit(2)


if __name__ == "__main__":
    main()
