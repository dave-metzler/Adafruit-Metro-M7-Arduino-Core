#!/usr/bin/env python3
"""Copy a .uf2 onto the Metro M7's TinyUF2 drive (volume label METROM7BOOT).

Double-click RESET on the board first so the drive appears.  Looks in the usual
mount points on Windows, macOS and Linux; or pass the drive path as 2nd argument.
"""
import glob, os, shutil, string, sys

def candidates():
    if os.name == "nt":
        for d in string.ascii_uppercase:
            yield "%s:\\" % d
    else:
        for pat in ("/Volumes/METROM7BOOT", "/media/*/METROM7BOOT", "/run/media/*/METROM7BOOT",
                    "/media/METROM7BOOT", "/mnt/METROM7BOOT"):
            yield from glob.glob(pat)

def find_drive():
    for c in candidates():
        if os.path.isfile(os.path.join(c, "INFO_UF2.TXT")):
            txt = open(os.path.join(c, "INFO_UF2.TXT"), errors="replace").read()
            if "Metro M7" in txt:
                return c
    return None

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    drive = sys.argv[2] if len(sys.argv) > 2 else find_drive()
    if not drive:
        print("Could not find the METROM7BOOT drive. Double-click RESET on the board, "
              "or copy %s onto it by hand." % sys.argv[1])
        return 1
    shutil.copy(sys.argv[1], drive)
    print("Copied %s to %s (the board reboots by itself)" % (sys.argv[1], drive))
    return 0

if __name__ == "__main__":
    sys.exit(main())
