#!/usr/bin/env bash
# Build a sketch for the Metro M7 outside the Arduino IDE (for CI / compile checks).
#
#   tools/build.sh examples/Blink/Blink.ino  [outdir]
#
# Needs arm-none-eabi-gcc on PATH, or set ARM_BIN=/path/to/toolchain/bin
set -euo pipefail

SKETCH=${1:?usage: build.sh sketch.ino [outdir]}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${2:-$ROOT/build/$(basename "${SKETCH%.ino}")}
PLAT=$ROOT/hardware/adafruit-metro-m7/imxrt1011
CORE=$PLAT/cores/imxrt1011
VARIANT=$PLAT/variants/metro_m7
PFX=${ARM_BIN:+$ARM_BIN/}arm-none-eabi-

mkdir -p "$OUT/obj"

CPU="-mcpu=cortex-m7 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16"
DEFS="-DARDUINO=10819 -DARDUINO_ARCH_IMXRT1011 -DARDUINO_ADAFRUIT_METRO_M7_1011 -DARDUINO_API_VERSION=10502"
LIBDIRS=$(ls -d "$PLAT"/libraries/* 2>/dev/null || true)
INC="-I$CORE -I$VARIANT ${EXTRA_CFLAGS:-}"
for d in $LIBDIRS; do INC="$INC -I$d"; done
COMMON="$CPU -Os -g -ffunction-sections -fdata-sections -Wall -Wextra -Wno-unused-parameter $DEFS $INC"
CFLAGS="$COMMON -std=gnu11"
CXXFLAGS="$COMMON -std=gnu++17 -fno-exceptions -fno-rtti -fno-threadsafe-statics"

# Sketch: .ino -> .cpp with Arduino.h prepended (the IDE also generates prototypes;
# these examples define things in order, so that isn't needed here).
SK_CPP=$OUT/sketch.cpp
{ echo '#include <Arduino.h>'; cat "$SKETCH"; } > "$SK_CPP"

OBJS=()
compile() {
  local src=$1 obj=$OUT/obj/$(echo "$1" | md5sum | cut -c1-8)_$(basename "$1").o
  case $src in
    *.c)   "${PFX}gcc"  $CFLAGS   -c "$src" -o "$obj" ;;
    *.cpp) "${PFX}g++"  $CXXFLAGS -c "$src" -o "$obj" ;;
  esac
  OBJS+=("$obj")
}

while IFS= read -r f; do compile "$f"; done < <(find "$CORE" "$VARIANT" -name '*.c' -o -name '*.cpp' | sort)
for d in $LIBDIRS; do while IFS= read -r f; do compile "$f"; done < <(find "$d" -name '*.c' -o -name '*.cpp' | sort); done
compile "$SK_CPP"

"${PFX}g++" $CPU -Wl,--gc-sections -Wl,-Map="$OUT/firmware.map" \
  ${EXTRA_LDFLAGS:-} -T "$VARIANT/imxrt1011.ld" -specs=nano.specs -specs=nosys.specs \
  "${OBJS[@]}" -lm -o "$OUT/firmware.elf"
"${PFX}objcopy" -O binary "$OUT/firmware.elf" "$OUT/firmware.bin"
python3 -I "$ROOT/tools/bin2uf2.py" "$OUT/firmware.bin" "$OUT/firmware.uf2"
"${PFX}size" "$OUT/firmware.elf"
echo "OUTPUT: $OUT/firmware.uf2"
