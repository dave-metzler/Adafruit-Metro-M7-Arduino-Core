#!/usr/bin/env python3
"""Host-side check for the Metro M7 native USB serial port.  Needs pyserial (pip install pyserial).

  1. Flash examples/UsbSerialTest (UsbSerialTest.uf2) to the board and plug in the USB-C cable.
  2. python3 tools/usb_check.py            (auto-finds the port by VID:PID 1209:0001)
     python3 tools/usb_check.py --port COM7        (or /dev/ttyACM0)
  Optional:  --touch   also tests the 1200-baud touch (the board should reboot into the
                       TinyUF2 drive; you then re-flash or reset it to get back).
"""
import argparse, os, sys, time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.exit("pyserial is required:  pip install pyserial")

VID, PID = 0x1209, 0x0001
results = []

def report(name, ok, detail=""):
    results.append(ok)
    print("%-34s %s  %s" % (name, "PASS" if ok else "FAIL", detail))

def find_port():
    for p in list_ports.comports():
        if p.vid == VID and p.pid == PID:
            return p.device
    return None

def read_exact(ser, n, timeout):
    buf = bytearray(); end = time.time() + timeout
    while len(buf) < n and time.time() < end:
        chunk = ser.read(min(4096, n - len(buf)))
        buf += chunk
    return bytes(buf)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port"); ap.add_argument("--touch", action="store_true")
    a = ap.parse_args()
    port = a.port or find_port()
    report("enumerated (port present)", port is not None, port or "no 1209:0001 device found")
    if not port:
        return finish()

    # 1. device -> host text, and line coding
    with serial.Serial(port, 57600, timeout=0.5) as s:
        s.dtr = True
        t = time.time() + 4; line = b""
        while time.time() < t and b"USB serial OK" not in line:
            line += s.read(256)
        report("banner received", b"USB serial OK" in line, line.decode(errors="replace").strip().splitlines()[-1:] and line.decode(errors="replace").strip().splitlines()[-1] or "nothing")
        report("baud passed to device", b"baud=57600" in line)

    # 2. echo (host -> device -> host)
    with serial.Serial(port, 115200, timeout=0, write_timeout=10) as s:
        s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
        s.write(b"E"); time.sleep(0.3); s.reset_input_buffer()
        data = os.urandom(131072)
        t0 = time.time(); back = bytearray(); i = 0
        while len(back) < len(data) and time.time() - t0 < 30:
            if i < len(data):
                n = min(1000, len(data) - i); s.write(data[i:i + n]); i += n
            chunk = s.read(4096)
            if chunk: back += chunk
            elif i >= len(data): time.sleep(0.005)
        dt = time.time() - t0
        bad = next((k for k in range(min(len(back), len(data))) if back[k] != data[k]), None)
        detail = "%d/%d bytes, %.0f KB/s" % (len(back), len(data), len(data) * 2 / 1000 / dt)
        if bad is not None:
            detail += ", first mismatch at byte %d\n    expected %s\n    got      %s" % (bad, data[bad:bad+16].hex(), bytes(back[bad:bad+16]).hex())
        report("echo 128 KiB", bytes(back) == data, detail)

    # 2b. host -> device only: the board verifies the bytes and reports
    with serial.Serial(port, 115200, timeout=0, write_timeout=10) as s:
        s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
        s.write(b"R"); time.sleep(0.3); s.reset_input_buffer()
        pat = bytes(i & 0xFF for i in range(65536)); i = 0; line = b""; t0 = time.time()
        while b"RXTEST" not in line or b"\n" not in line.split(b"RXTEST")[-1]:
            if i < len(pat):
                try: i += s.write(pat[i:i + 1000]) or 0
                except serial.SerialTimeoutException: break
            line += s.read(256)
            if time.time() - t0 > 15: break
        txt = line.decode(errors="replace").strip()
        report("host->device 64 KiB (board checks)", "bytes=65536 errors=0" in txt, txt[txt.find("RXTEST"):] if "RXTEST" in txt else "no reply (host sent %d bytes)" % i)

    # 2c. same, but paced: one 64-byte packet every 3 ms (separates "too fast" from "wrong")
    with serial.Serial(port, 115200, timeout=0, write_timeout=10) as s:
        s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
        s.write(b"P"); time.sleep(0.3); s.reset_input_buffer()
        pat = bytes(i & 0xFF for i in range(4096)); line = b""; t0 = time.time()
        for i in range(0, 4096, 64):
            s.write(pat[i:i + 64]); s.flush(); time.sleep(0.003); line += s.read(256)
        while b"RXTEST" not in line or b"\n" not in line.split(b"RXTEST")[-1]:
            line += s.read(256)
            if time.time() - t0 > 15: break
        txt = line.decode(errors="replace").strip()
        report("host->device 4 KiB paced", "bytes=4096 errors=0" in txt, txt[txt.find("RXTEST"):] if "RXTEST" in txt else "no reply")

    # 2d. dump controller state + packet log, then try the experimental variants
    with serial.Serial(port, 115200, timeout=0.3) as s:
        s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
        s.write(b"D"); buf = b""; t0 = time.time()
        while b"DUMPEND" not in buf and time.time() - t0 < 5: buf += s.read(512)
        print("--- device dump (after the paced test) ---"); print(buf.decode(errors="replace").strip()); print("---")
    for v in "01234567":
        with serial.Serial(port, 115200, timeout=0, write_timeout=10) as s:
            s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
            s.write(v.encode()); time.sleep(0.3); s.write(b"P"); time.sleep(0.3); s.reset_input_buffer()
            line = b""; t0 = time.time()
            for i in range(0, 4096, 64):
                s.write(bytes((i + k) & 0xFF for k in range(64))); s.flush(); time.sleep(0.003); line += s.read(256)
            while b"\n" not in line.split(b"RXTEST")[-1] or b"RXTEST" not in line:
                line += s.read(256)
                if time.time() - t0 > 15: break
            txt = line.decode(errors="replace").strip()
            report("  paced, variant " + v, "bytes=4096 errors=0" in txt, txt[txt.find("RXTEST"):][:60] if "RXTEST" in txt else "no reply")

    # 3. bulk device -> host, pattern check
    with serial.Serial(port, 115200, timeout=0.2) as s:
        s.dtr = True; time.sleep(0.5); s.reset_input_buffer()
        s.write(b"G"); t0 = time.time()
        got = read_exact(s, 262144, 20); dt = time.time() - t0
        ok = len(got) == 262144 and got == bytes(i & 0xFF for i in range(262144))
        report("device->host 256 KiB", ok, "%d bytes, %.0f KB/s" % (len(got), len(got) / 1000 / dt))

    # 4. close / reopen still works
    with serial.Serial(port, 115200, timeout=0.5) as s:
        s.dtr = True; time.sleep(1.5)
        report("reopen after close", b"USB serial OK" in s.read(512))

    if a.touch:
        print("1200-baud touch: opening at 1200 baud and closing ...")
        s = serial.Serial(port, 1200); s.dtr = True; time.sleep(0.2); s.dtr = False; s.close()
        time.sleep(3)
        gone = find_port() is None
        report("touch -> port disappeared", gone, "check that the METROM7BOOT drive appeared" if gone else "")
    return finish()

def finish():
    print("\nALL PASSED" if all(results) else "\nSOME TESTS FAILED")
    return 0 if all(results) else 1

if __name__ == "__main__":
    sys.exit(main())
