// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include <Arduino.h>
#include "api/HardwareSPI.h"

/* SPI master on LPSPI1:  MISO = GPIO_AD_03, MOSI = GPIO_AD_04, SCK = GPIO_AD_06
 * (the 2x3 ICSP header).  Chip select is left to the sketch (use any GPIO). */
class LpSpi : public arduino::HardwareSPI {
public:
    void begin() override;
    void end() override;
    void beginTransaction(SPISettings settings) override;
    void endTransaction(void) override {}

    uint8_t  transfer(uint8_t data) override;
    uint16_t transfer16(uint16_t data) override;
    void     transfer(void *buf, size_t count) override;

    void usingInterrupt(int) override {}
    void notUsingInterrupt(int) override {}
    void attachInterrupt() override {}
    void detachInterrupt() override {}

    /* Measured clock (Hz) feeding the LPSPI baud-rate divider (for diagnostics). */
    uint32_t sourceClockHz() const { return src_hz_; }

private:
    void measureClock();
    void configure(uint32_t hz, BitOrder order, SPIMode mode);
    uint32_t src_hz_ = 0;
    uint32_t tcr_    = 0;      /* CPOL | CPHA | PRESCALE | LSBF; FRAMESZ added per transfer */
    bool lsb_        = false;
    bool began_      = false;
    uint8_t depth_   = 4;      /* FIFO depth in words */
};

extern LpSpi SPI;

#endif
