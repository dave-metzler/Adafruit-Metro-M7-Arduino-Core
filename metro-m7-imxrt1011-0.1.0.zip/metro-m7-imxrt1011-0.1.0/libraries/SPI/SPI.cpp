// SPDX-License-Identifier: LGPL-2.1-or-later
#include "SPI.h"

using namespace arduino;

LpSpi SPI;

#define PAD_SPI 0x10F0u          /* DSE 6, speed 3 (max), keeper */

#define CR_MEN   (1u << 0)
#define CR_RST   (1u << 1)
#define CR_RTF   (1u << 8)
#define CR_RRF   (1u << 9)
#define SR_TCF   (1u << 10)
#define SR_CLR   0x00003F00u     /* write-1-to-clear flags */
#define TCR_RXMSK (1u << 19)

static inline uint32_t rxCount() { return (LPSPI1_FSR >> 16) & 0x1F; }
static inline uint32_t txCount() { return LPSPI1_FSR & 0x1F; }

/* Run one long frame with no data collected and time it: 512 bits at SCKDIV=254 (/256). */
void LpSpi::measureClock()
{
    LPSPI1_CR = CR_RST; LPSPI1_CR = 0;
    LPSPI1_CFGR1 = 1;                                   /* master */
    LPSPI1_CCR = 254;                                   /* SCK = src / 256, no extra delays */
    LPSPI1_FCR = 0;
    LPSPI1_CR = CR_MEN;
    LPSPI1_SR = SR_CLR;

    LPSPI1_TCR = TCR_RXMSK | 511u;                      /* prescale 1, 512-bit frame, ignore RX */
    uint32_t t0 = micros();
    for (int i = 0; i < 16; i++) LPSPI1_TDR = 0;        /* 16 x 32 bits = 512 bits */
    while (!(LPSPI1_SR & SR_TCF)) { if (micros() - t0 > 50000u) break; }
    uint32_t us = micros() - t0;
    LPSPI1_SR = SR_CLR;
    LPSPI1_CR = 0;
    if (us == 0) us = 1;
    src_hz_ = (uint32_t)(((uint64_t)512u * 256u * 1000000u) / us);
    src_hz_ = ((src_hz_ + 50000u) / 100000u) * 100000u; /* round to 100 kHz */
}

void LpSpi::begin()
{
    if (began_) return;
    began_ = true;

    CCM_CCGR1 |= 3u;                                    /* LPSPI1 clock gate */

    /* Pads: ALT0 = LPSPI1_SCK / SDO / SDI, with the input-select values from NXP's pin data */
    IOMUXC_SW_MUX_CTL_PAD_GPIO_AD_06 = 0;  IOMUXC_LPSPI1_SCK_SELECT_INPUT = 0;
    IOMUXC_SW_MUX_CTL_PAD_GPIO_AD_04 = 0;  IOMUXC_LPSPI1_SDO_SELECT_INPUT = 0;
    IOMUXC_SW_MUX_CTL_PAD_GPIO_AD_03 = 0;  IOMUXC_LPSPI1_SDI_SELECT_INPUT = 0;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_AD_06 = PAD_SPI;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_AD_04 = PAD_SPI;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_AD_03 = PAD_SPI;

    depth_ = (uint8_t)(1u << (LPSPI1_PARAM & 0xFF));    /* PARAM.TXFIFO is log2(depth) */
    if (depth_ < 4 || depth_ > 16) depth_ = 4;
    measureClock();
    configure(4000000, MSBFIRST, SPI_MODE0);
}

void LpSpi::end()
{
    LPSPI1_CR = 0;
    began_ = false;
    pinMode(PIN_SPI_MISO, INPUT);
    pinMode(PIN_SPI_MOSI, INPUT);
    pinMode(PIN_SPI_SCK, INPUT);
}

void LpSpi::configure(uint32_t hz, BitOrder order, SPIMode mode)
{
    if (hz == 0) hz = 1;
    /* Total divider needed (rounded up so we never exceed the requested rate). */
    uint32_t need = (src_hz_ + hz - 1) / hz;
    if (need < 2) need = 2;
    uint32_t p = 0, d = need;
    while (p < 7 && d > 257u) { p++; d = (need + (1u << p) - 1) >> p; }
    if (d > 257u) d = 257u;
    if (d < 2) d = 2;
    uint32_t sckdiv = d - 2;

    LPSPI1_CR = CR_RST; LPSPI1_CR = 0;                  /* CCR can only change while disabled */
    LPSPI1_CFGR1 = 1;                                   /* master, PCS pin unused (CS is a GPIO) */
    LPSPI1_CCR = sckdiv | (sckdiv << 8);                /* DBT = one SCK period; no PCS delays */
    LPSPI1_FCR = 0;
    LPSPI1_CR = CR_MEN;
    LPSPI1_SR = SR_CLR;

    lsb_ = (order == LSBFIRST);
    tcr_ = ((uint32_t)((mode >> 1) & 1) << 31) | ((uint32_t)(mode & 1) << 30) |
           (p << 27) | (lsb_ ? (1u << 23) : 0);
}

void LpSpi::beginTransaction(SPISettings s)
{
    if (!began_) begin();
    configure(s.getClockFreq(), s.getBitOrder(), s.getDataMode());
}

uint8_t LpSpi::transfer(uint8_t data)
{
    LPSPI1_TCR = tcr_ | 7u;
    LPSPI1_TDR = data;
    while (rxCount() == 0) { }
    return (uint8_t)LPSPI1_RDR;
}

uint16_t LpSpi::transfer16(uint16_t data)
{
    LPSPI1_TCR = tcr_ | 15u;
    LPSPI1_TDR = data;
    while (rxCount() == 0) { }
    return (uint16_t)LPSPI1_RDR;
}

void LpSpi::transfer(void *buf, size_t count)
{
    uint8_t *p = (uint8_t *)buf;

    /* Whole 4-byte groups go as long 32-bit-word frames so SCK never pauses between bytes
     * (up to 512 bytes = 4096 bits per frame).  Word packing follows the shift direction:
     * MSB-first sends the top byte first, LSB-first sends the bottom byte first. */
    while (count >= 4) {
        size_t chunk = count & ~(size_t)3;
        if (chunk > 512) chunk = 512;
        uint32_t words = (uint32_t)(chunk / 4);
        LPSPI1_TCR = tcr_ | (uint32_t)(words * 32u - 1u);

        uint32_t tx = 0, rx = 0;
        while (rx < words) {
            while (tx < words && (tx - rx) < depth_ && txCount() < depth_) {
                uint32_t w;
                const uint8_t *s = p + tx * 4;
                if (lsb_) w = s[0] | (s[1] << 8) | (s[2] << 16) | ((uint32_t)s[3] << 24);
                else      w = ((uint32_t)s[0] << 24) | (s[1] << 16) | (s[2] << 8) | s[3];
                LPSPI1_TDR = w;
                tx++;
            }
            while (rxCount() > 0 && rx < words) {
                uint32_t w = LPSPI1_RDR;
                uint8_t *d = p + rx * 4;
                if (lsb_) { d[0] = w; d[1] = w >> 8; d[2] = w >> 16; d[3] = w >> 24; }
                else      { d[0] = w >> 24; d[1] = w >> 16; d[2] = w >> 8; d[3] = w; }
                rx++;
            }
        }
        p += chunk; count -= chunk;
    }
    while (count--) { *p = transfer(*p); p++; }
}
