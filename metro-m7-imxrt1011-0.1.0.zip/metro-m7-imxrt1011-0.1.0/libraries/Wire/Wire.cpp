// SPDX-License-Identifier: LGPL-2.1-or-later
#include "Wire.h"

TwoWire Wire;

#define I2C_SRC_HZ   24000000u                 /* LPI2C root clock = 24 MHz crystal (set in begin()) */

#define MCR_MEN      (1u << 0)
#define MCR_RST      (1u << 1)
#define MCR_RTF      (1u << 8)
#define MCR_RRF      (1u << 9)
#define MSR_SDF      (1u << 9)
#define MSR_NDF      (1u << 10)
#define MSR_ALF      (1u << 11)
#define MSR_FEF      (1u << 12)
#define MSR_PLTF     (1u << 13)
#define MSR_ERRORS   (MSR_ALF | MSR_FEF | MSR_PLTF)
#define MSR_CLEAR    0x00007F00u               /* write-1-to-clear flags */
#define MSR_MBF      (1u << 24)

#define CMD_TX       (0u << 8)
#define CMD_RX       (1u << 8)
#define CMD_STOP     (2u << 8)
#define CMD_START    (4u << 8)                 /* START + address byte, expect ACK */

#define PAD_I2C      0x18B0u                   /* DSE 6, speed 2, open drain, keeper */
#define TIMEOUT_US   25000u

static inline uint32_t txCount() { return LPI2C1_MFSR & 0x7; }
static inline uint32_t rxCount() { return (LPI2C1_MFSR >> 16) & 0x7; }

void TwoWire::begin()
{
    if (began_) return;
    began_ = true;

    CCM_CCGR2 |= (3u << 6);                                                 /* LPI2C1 clock gate */
    CCM_CSCDR2 = (CCM_CSCDR2 & ~((1u << 18) | (0x3Fu << 19))) | (1u << 18);  /* root = 24 MHz osc, /1 */

    /* ALT3 with SION (bit 4: input path forced on, needed for open-drain I2C readback) */
    IOMUXC_SW_MUX_CTL_PAD_GPIO_01 = 0x13;  IOMUXC_LPI2C1_SDA_SELECT_INPUT = 3;
    IOMUXC_SW_MUX_CTL_PAD_GPIO_02 = 0x13;  IOMUXC_LPI2C1_SCL_SELECT_INPUT = 3;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_01 = PAD_I2C;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_02 = PAD_I2C;

    uint32_t d = 1u << (LPI2C1_PARAM & 0xF);                                /* PARAM.MTXFIFO is log2(depth) */
    depth_ = (d >= 2 && d <= 4) ? (uint8_t)d : 4;
    applyClock();
}

void TwoWire::end()
{
    LPI2C1_MCR = 0;
    began_ = false; held_ = false;
    pinMode(PIN_WIRE_SDA, INPUT);
    pinMode(PIN_WIRE_SCL, INPUT);
}

void TwoWire::setClock(uint32_t freq)
{
    clock_hz_ = freq ? freq : 100000;
    if (began_) applyClock();
}

/* Program the baud rate.  SCL period = CLKLO + CLKHI + 2 + ((2 + FILT) >> PRESCALE) cycles of
 * (24 MHz >> PRESCALE); low phase is 55 % of the period up to 100 kHz and 62 % above (nominal I2C minimum low/high times met at 100 k, 400 k, 1 MHz). */
void TwoWire::applyClock()
{
    uint32_t p, clklo = 3, clkhi = 1;
    const uint32_t lowpct = (clock_hz_ <= 100000) ? 55 : 62;   /* std mode needs high >= 4.0 us; fast modes need a longer low */
    for (p = 0; p < 8; p++) {
        uint32_t tick   = I2C_SRC_HZ >> p;
        uint32_t cycles = (tick + clock_hz_ - 1) / clock_hz_;        /* round up: never exceed request */
        uint32_t extra  = 2 + (2u >> p);
        if (cycles < extra + 4) { clklo = 3; clkhi = 1; break; }     /* faster than the controller can go */
        uint32_t n = cycles - extra;
        clklo = (n * lowpct + 99) / 100; if (clklo < 3) clklo = 3;
        clkhi = n - clklo;        if (clkhi < 1) clkhi = 1;
        if (clklo <= 63 && clkhi <= 63) break;
    }
    if (p == 8) { p = 7; clklo = 63; clkhi = 63; }

    uint32_t sethold = clkhi < 2 ? 2 : clkhi;
    uint32_t datavd  = clkhi / 2; if (datavd < 1) datavd = 1;
    if (sethold > 63) sethold = 63;

    LPI2C1_MCR = MCR_RST; LPI2C1_MCR = 0;                           /* config only while disabled */
    LPI2C1_MCFGR1 = p;                                              /* prescale; 2-pin open drain */
    LPI2C1_MCFGR2 = 0;                                              /* no bus-idle timeout, no filters */
    LPI2C1_MCCR0  = clklo | (clkhi << 8) | (sethold << 16) | (datavd << 24);
    LPI2C1_MFCR   = 0;
    LPI2C1_MSR    = MSR_CLEAR;
    LPI2C1_MCR    = MCR_MEN;
    held_ = false;
}

void TwoWire::resetMaster() { applyClock(); }

bool TwoWire::pushCmd(uint32_t cmd)
{
    uint32_t t0 = micros();
    while (txCount() >= depth_) {
        if (LPI2C1_MSR & (MSR_ERRORS | MSR_NDF)) return false;
        if (micros() - t0 > TIMEOUT_US) return false;
    }
    LPI2C1_MTDR = cmd;
    return true;
}

bool TwoWire::waitTxEmpty()
{
    uint32_t t0 = micros();
    while (txCount() != 0) {
        if (LPI2C1_MSR & (MSR_ERRORS | MSR_NDF)) return false;
        if (micros() - t0 > TIMEOUT_US) return false;
    }
    return true;
}

/* Get the bus back to idle after an error: flush FIFOs, send STOP, wait for it. */
void TwoWire::abortBus()
{
    LPI2C1_MCR |= MCR_RTF | MCR_RRF;
    LPI2C1_MSR = MSR_CLEAR;
    LPI2C1_MTDR = CMD_STOP;
    uint32_t t0 = micros();
    while (!(LPI2C1_MSR & MSR_SDF)) {
        if (micros() - t0 > TIMEOUT_US) { resetMaster(); return; }    /* wedged: reset the controller */
    }
    LPI2C1_MSR = MSR_CLEAR;
    held_ = false;
}

/* Issue START + address byte and wait for its ACK/NACK. */
uint8_t TwoWire::startPhase(uint8_t addrByte)
{
    if (!held_) {                                                   /* otherwise this is a repeated START */
        uint32_t t0 = micros();
        while (LPI2C1_MSR & MSR_MBF) {
            if (micros() - t0 > TIMEOUT_US) { resetMaster(); return 4; }
        }
    }
    LPI2C1_MSR = MSR_CLEAR;
    uint32_t t1 = micros();
    if (!pushCmd(CMD_START | addrByte)) return (LPI2C1_MSR & MSR_NDF) ? 2 : 4;

    /* Address byte (9 SCL clocks) is in flight once the FIFO drains; wait up to 14 SCL periods
     * for a NACK to show.  A NACK ends the wait immediately. */
    uint32_t window = (14u * 1000000u) / clock_hz_ + 2;
    while (true) {
        uint32_t s = LPI2C1_MSR;
        if (s & MSR_NDF)    return 2;
        if (s & MSR_ERRORS) return 4;
        if (txCount() == 0 && (uint32_t)(micros() - t1) >= window) return 0;
        if ((uint32_t)(micros() - t1) > TIMEOUT_US) return 4;
    }
}

void TwoWire::beginTransmission(uint8_t address)
{
    tx_addr_ = address;
    tx_len_ = 0;
}

size_t TwoWire::write(uint8_t data)
{
    if (tx_len_ >= BUFFER_LENGTH) return 0;
    tx_buf_[tx_len_++] = data;
    return 1;
}

/* Returns Arduino codes: 0 ok, 1 too long, 2 NACK on address, 3 NACK on data, 4 other error. */
uint8_t TwoWire::endTransmission(bool stop)
{
    if (!began_) begin();
    uint8_t r = startPhase((uint8_t)(tx_addr_ << 1));
    if (r) { abortBus(); return r; }

    for (uint8_t i = 0; i < tx_len_; i++) {
        if (!pushCmd(CMD_TX | tx_buf_[i])) {
            uint32_t s = LPI2C1_MSR;
            abortBus();
            return (s & MSR_NDF) ? 3 : 4;
        }
    }
    if (stop) {
        if (!pushCmd(CMD_STOP)) {
            uint32_t s = LPI2C1_MSR;
            abortBus();
            return (s & MSR_NDF) ? 3 : 4;
        }
        uint32_t t0 = micros();
        while (!(LPI2C1_MSR & MSR_SDF)) {
            uint32_t s = LPI2C1_MSR;
            if (s & MSR_NDF) { abortBus(); return 3; }
            if (s & MSR_ERRORS) { abortBus(); return 4; }
            if (micros() - t0 > TIMEOUT_US) { abortBus(); return 4; }
        }
        LPI2C1_MSR = MSR_CLEAR;
        held_ = false;
    } else {
        if (!waitTxEmpty()) {
            uint32_t s = LPI2C1_MSR;
            abortBus();
            return (s & MSR_NDF) ? 3 : 4;
        }
        held_ = true;
    }
    tx_len_ = 0;
    return 0;
}

size_t TwoWire::requestFrom(uint8_t address, size_t len, bool stop)
{
    if (!began_) begin();
    rx_len_ = rx_pos_ = 0;
    if (len == 0) return 0;
    if (len > BUFFER_LENGTH) len = BUFFER_LENGTH;

    uint8_t r = startPhase((uint8_t)((address << 1) | 1));
    if (r) { abortBus(); return 0; }

    if (!pushCmd(CMD_RX | (uint32_t)(len - 1))) { abortBus(); return 0; }
    if (stop && !pushCmd(CMD_STOP)) { abortBus(); return 0; }

    uint32_t t0 = micros();
    while (rx_len_ < len) {
        if (rxCount() > 0) {
            uint32_t v = LPI2C1_MRDR;
            if (!(v & (1u << 14))) { rx_buf_[rx_len_++] = (uint8_t)v; t0 = micros(); }
        } else {
            if (LPI2C1_MSR & (MSR_ERRORS | MSR_NDF)) { abortBus(); return rx_len_; }
            if (micros() - t0 > TIMEOUT_US) { abortBus(); return rx_len_; }
        }
    }
    if (stop) {
        t0 = micros();
        while (!(LPI2C1_MSR & MSR_SDF)) { if (micros() - t0 > TIMEOUT_US) { abortBus(); return rx_len_; } }
        LPI2C1_MSR = MSR_CLEAR;
        held_ = false;
    } else {
        held_ = true;
    }
    return rx_len_;
}
