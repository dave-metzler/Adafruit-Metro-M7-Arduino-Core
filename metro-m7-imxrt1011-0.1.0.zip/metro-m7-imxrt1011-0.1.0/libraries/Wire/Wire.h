// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef TwoWire_h
#define TwoWire_h

#include <Arduino.h>
#include "api/HardwareI2C.h"

#define BUFFER_LENGTH 64

/* I2C controller on LPI2C1: SDA = GPIO_01, SCL = GPIO_02 (header SDA/SCL and STEMMA QT).
 * Controller (master) mode only; begin(address), onReceive and onRequest are accepted but
 * do nothing.  The board has 10k pull-ups on SDA/SCL. */
class TwoWire : public arduino::HardwareI2C {
public:
    void begin() override;
    void begin(uint8_t) override { begin(); }     /* peripheral mode not implemented */
    void end() override;
    void setClock(uint32_t freq) override;

    void    beginTransmission(uint8_t address) override;
    uint8_t endTransmission(bool stopBit) override;
    uint8_t endTransmission(void) override { return endTransmission(true); }

    size_t requestFrom(uint8_t address, size_t len, bool stopBit) override;
    size_t requestFrom(uint8_t address, size_t len) override { return requestFrom(address, len, true); }

    void onReceive(void (*)(int)) override {}
    void onRequest(void (*)(void)) override {}

    size_t write(uint8_t data) override;
    using Print::write;
    int available(void) override { return rx_len_ - rx_pos_; }
    int read(void) override { return rx_pos_ < rx_len_ ? rx_buf_[rx_pos_++] : -1; }
    int peek(void) override { return rx_pos_ < rx_len_ ? rx_buf_[rx_pos_] : -1; }
    void flush(void) override {}

private:
    void     applyClock();
    void     resetMaster();
    uint8_t  startPhase(uint8_t addrByte);      /* 0 ok, 2 address NACK, 4 other error */
    void     abortBus();
    bool     pushCmd(uint32_t cmd);
    bool     waitTxEmpty();

    uint32_t clock_hz_ = 100000;
    bool     began_ = false;
    bool     held_  = false;                    /* bus held after endTransmission(false) */
    uint8_t  tx_addr_ = 0;
    uint8_t  tx_buf_[BUFFER_LENGTH];
    uint8_t  tx_len_ = 0;
    uint8_t  rx_buf_[BUFFER_LENGTH];
    uint8_t  rx_len_ = 0, rx_pos_ = 0;
    uint8_t  depth_ = 4;
};

extern TwoWire Wire;

#endif
