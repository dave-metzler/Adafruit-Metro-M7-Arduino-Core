// SPDX-License-Identifier: LGPL-2.1-or-later
// Placeholder so the Arduino IDE treats this folder as a library; the sketches live in examples/.
#pragma once
