// SPDX-License-Identifier: LGPL-2.1-or-later
// SPI loopback self-test.  One jumper wire: MOSI -> MISO on the 2x3 ICSP header
// (standard ICSP layout: pin 1 MISO, 2 +5V, 3 SCK, 4 MOSI, 5 RESET, 6 GND; check the silkscreen).
// Anything the sketch sends is received straight back, so every test compares sent vs received.
//
// Result cycle: LED solid ON 2 s (start marker), then
//   3 slow blinks = all passed
//   10 fast blinks = failure; then N slow blinks say which test (1..7):
//     1 byte transfers, modes 0-3, MSB first     2 byte transfers, LSB first
//     3 transfer16, MSB and LSB first            4 buffer transfers (many lengths), MSB+LSB
//     5 buffer at 12 MHz                         6 timing at 1 MHz     7 timing at 10 MHz
// Then the measured LPSPI source clock in MHz is blinked digit by digit (a zero is one tiny
// flicker); expect a sensible value like 132 or 105.

#include <SPI.h>

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}
static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

static uint32_t seed = 12345;
static uint8_t rnd() { seed = seed * 1664525u + 1013904223u; return seed >> 24; }

static bool bufTest(uint32_t hz, BitOrder order, int mode, size_t n) {
  uint8_t tx[300], buf[300];
  for (size_t i = 0; i < n; i++) tx[i] = buf[i] = rnd();
  SPI.beginTransaction(SPISettings(hz, order, mode));
  SPI.transfer(buf, n);
  SPI.endTransaction();
  return memcmp(tx, buf, n) == 0;
}

static int runTests() {
  // 1: bytes, all modes, MSB first, 1 MHz
  for (int m = 0; m < 4; m++) {
    SPI.beginTransaction(SPISettings(1000000, MSBFIRST, m));
    for (int i = 0; i < 16; i++) { uint8_t v = rnd(); if (SPI.transfer(v) != v) return 1; }
    SPI.endTransaction();
  }
  // 2: bytes, LSB first
  for (int m = 0; m < 4; m += 3) {
    SPI.beginTransaction(SPISettings(1000000, LSBFIRST, m));
    for (int i = 0; i < 16; i++) { uint8_t v = rnd(); if (SPI.transfer(v) != v) return 2; }
    SPI.endTransaction();
  }
  // 3: 16-bit
  for (int o = 0; o < 2; o++) {
    SPI.beginTransaction(SPISettings(1000000, o ? MSBFIRST : LSBFIRST, SPI_MODE0));
    for (int i = 0; i < 8; i++) {
      uint16_t v = (rnd() << 8) | rnd();
      if (SPI.transfer16(v) != v) return 3;
    }
    SPI.endTransaction();
  }
  // 4: buffers of many lengths (hits the 32-bit-word path and the 1..3 byte tails)
  const size_t lens[] = {1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17, 31, 32, 33, 64, 100, 255, 300};
  for (int o = 0; o < 2; o++)
    for (size_t k = 0; k < sizeof(lens) / sizeof(lens[0]); k++)
      if (!bufTest(4000000, o ? MSBFIRST : LSBFIRST, SPI_MODE0, lens[k])) return 4;
  // 5: fast
  if (!bufTest(12000000, MSBFIRST, SPI_MODE0, 256)) return 5;
  if (!bufTest(12000000, MSBFIRST, SPI_MODE3, 256)) return 5;
  // 6/7: timing of a 256-byte buffer (2048 bits)
  uint8_t buf[256] = {0};
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  uint32_t t0 = micros(); SPI.transfer(buf, 256); uint32_t us = micros() - t0;
  SPI.endTransaction();
  if (us < 2048 || us > 2250) return 6;
  SPI.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE0));
  t0 = micros(); SPI.transfer(buf, 256); us = micros() - t0;
  SPI.endTransaction();
  if (us < 195 || us > 260) return 7;
  return 0;
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  SPI.begin();
}

void loop() {
  int r = runTests();
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  if (r == 0) blinks(3, 400, 400);
  else { blinks(10, 60, 60); delay(1200); blinks(r, 400, 400); }
  delay(1500);
  blinkDigits((SPI.sourceClockHz() + 500000u) / 1000000u);
  delay(4000);
}
