// Serial.printf demo: formatted output on the native USB port (and Serial1 the same way).
void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 4000) { }     // wait for a terminal, but not forever
}

void loop() {
  static uint32_t n = 0;
  Serial.printf("count=%lu  uptime=%lu ms  hex=0x%08lX  float=%.3f  text=%s  char=%c\n",
                (unsigned long)n++, (unsigned long)millis(), (unsigned long)(0xC0FFEE00u + n),
                3.14159f * n, "hello", (int)('A' + (n % 26)));
  Serial.printf("%-10s|%10s|%5d|%-5d|%05d\n", "left", "right", 42, 42, 42);
  Serial.printf("a long line follows (more than 128 characters, to test the heap path): %s\n",
                "0123456789012345678901234567890123456789012345678901234567890123456789"
                "0123456789012345678901234567890123456789");
  delay(1000);
}
