// SPDX-License-Identifier: LGPL-2.1-or-later
// USB bring-up diagnostic.  Plug the USB-C cable into a computer, run this, and watch D13.
//
// Each cycle: LED solid ON 2 s (start marker), then one number of blinks = how far the USB
// enumeration got (the digit blinks; a long pause separates it from the next cycle):
//   1 = USB controller started, but the host never reset the bus (cable/power/PHY problem)
//   2 = host reset the bus, but sent no requests
//   3 = host talked to us (first SETUP packet received) but did not finish assigning an address
//   4 = address assigned, but the host did not select the configuration
//   5 = fully enumerated (the computer should now show a serial port)
//   6 = enumerated AND a terminal has the port open
// After that, extras: 10 fast blinks = controller error flagged, 5 fast blinks = PLL did not lock.
//
// Then a 0.6 s flash and the counters, each as digits: SETUP packets handled, bus resets,
// controller errors, bRequest of the last request, high byte of its wValue.
// If the port is open you also get a text line each cycle on Serial.

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}

static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
  delay(1200);
}

static int stage() {
  uint32_t f = usb_debug_flags();
  if (!(f & USB_DBG_INIT))       return 0;
  if (!(f & USB_DBG_RESET))      return 1;
  if (!(f & USB_DBG_SETUP))      return 2;
  if (!(f & USB_DBG_ADDRESSED))  return 3;
  if (!(f & USB_DBG_CONFIGURED)) return 4;
  if (!(f & USB_DBG_DTR))        return 5;
  return 6;
}

void setup() { pinMode(LED_BUILTIN, OUTPUT); }

void loop() {
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  int s = stage();
  uint32_t f = usb_debug_flags();
  if (s == 0) blinks(1, 30, 30); else blinks(s, 250, 250);
  delay(900);
  if (f & USB_DBG_ERROR)    { blinks(10, 60, 60); delay(500); }
  if (f & USB_DBG_PLL_FAIL) { blinks(5, 60, 60);  delay(500); }
  // Counters: SETUP packets handled, bus resets, controller errors, last request (bRequest, wValue high byte)
  digitalWrite(LED_BUILTIN, HIGH); delay(600); digitalWrite(LED_BUILTIN, LOW); delay(1200);
  blinkDigits(g_usb_stats[USB_STAT_SETUPS]);
  blinkDigits(g_usb_stats[USB_STAT_RESETS]);
  blinkDigits(g_usb_stats[USB_STAT_UEI]);
  blinkDigits((g_usb_stats[USB_STAT_LAST_REQ] >> 16) & 0xFF);
  blinkDigits((g_usb_stats[USB_STAT_LAST_REQ] >> 8) & 0xFF);
  if (Serial) {
    Serial.print("UsbDiag stage="); Serial.print(s);
    Serial.print(" flags=0x");      Serial.print(f, HEX);
    Serial.print(" baud=");         Serial.println(Serial.baud());
  }
  delay(3000);
}
