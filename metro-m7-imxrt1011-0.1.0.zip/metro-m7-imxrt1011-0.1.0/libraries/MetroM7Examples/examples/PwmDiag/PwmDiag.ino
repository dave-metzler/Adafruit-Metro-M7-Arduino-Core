// SPDX-License-Identifier: LGPL-2.1-or-later
// PWM diagnostic: no wiring needed.  Reports on D13.
//
// Each cycle: LED solid ON 2 s (start marker), then
//   the measured PWM peripheral clock in MHz, digit by digit (a zero is one tiny flicker),
//   e.g. 125 MHz = 1 blink, 2 blinks, 5 blinks.
//   Then 3 s of PWM breathing on D13 (a visual check), then a 4 s pause.
// A clock reading of 0 (one flicker) means the PWM counters aren't running.

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}
static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

void setup() { pinMode(LED_BUILTIN, OUTPUT); }

void loop() {
  uint32_t mhz = (analogWriteClockHz() + 500000u) / 1000000u;
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  blinkDigits(mhz);
  delay(1000);
  for (int i = 1; i < 255; i += 2) { analogWrite(13, i); delay(6); }
  for (int i = 254; i > 0; i -= 2) { analogWrite(13, i); delay(6); }
  analogWrite(13, 0);
  pinMode(LED_BUILTIN, OUTPUT);
  delay(4000);
}
