// SPDX-License-Identifier: LGPL-2.1-or-later
// analogWrite (PWM) self-test.  One jumper wire: D12 -> D2.
//
// 1) For ~4 s the D13 LED "breathes" (smooth fade up and down) -- a visual check of PWM
//    on D13 that needs no wiring.
// 2) The sketch then measures D12's PWM on D2 (duty cycle and frequency) in 8 tests.
//
// Result cycle: LED solid ON 2 s (start marker), then
//   3 slow blinks = all passed
//   10 fast blinks = failure; then N slow blinks say which test (1..8):
//     1 duty 25%   2 duty 50%   3 duty 75%   4 default frequency (4 kHz)
//     5 analogWriteFrequency(1 kHz)   6 analogWrite(0) -> constant LOW
//     7 analogWrite(255) -> constant HIGH   8 PWM works again after a constant level
// A missing wire fails tests 1-5 and 8 (no edges), and passes 6 (stays low).

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}

struct Meas { uint32_t high, total, rising; };

// Sample D2 for 100 ms.
static Meas measure() {
  Meas m = {0, 0, 0};
  int prev = digitalRead(2);
  uint32_t t0 = micros();
  while ((uint32_t)(micros() - t0) < 100000u) {
    int v = digitalRead(2);
    m.total++;
    if (v) m.high++;
    if (v && !prev) m.rising++;
    prev = v;
  }
  return m;
}

static bool dutyIs(int per_mille) {
  Meas m = measure();
  if (m.total == 0) return false;
  int got = (int)((uint64_t)m.high * 1000 / m.total);
  return abs(got - per_mille) <= 30;      // +/- 3 %
}
static bool freqIs(int hz) {
  Meas m = measure();
  int got = (int)(m.rising * 10);         // rising edges in 100 ms -> Hz
  return abs(got - hz) <= hz / 50 + 10;   // +/- 2 % (+10 Hz slack for the 100 ms window)
}

static int runTests() {
  analogWrite(12, 64);  delay(20); if (!dutyIs(251)) return 1;
  analogWrite(12, 128); delay(20); if (!dutyIs(502)) return 2;
  analogWrite(12, 192); delay(20); if (!dutyIs(753)) return 3;
  analogWrite(12, 128); delay(20); if (!freqIs(4000)) return 4;
  analogWriteFrequency(12, 1000); analogWrite(12, 128); delay(20);
  if (!freqIs(1000) || !dutyIs(502)) return 5;
  analogWrite(12, 0);   delay(20); { Meas m = measure(); if (m.high != 0) return 6; }
  analogWrite(12, 255); delay(20); { Meas m = measure(); if (m.high != m.total) return 7; }
  analogWrite(12, 128); delay(20); if (!dutyIs(502)) return 8;
  analogWriteFrequency(12, 4000);        // restore for the next cycle
  return 0;
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(2, INPUT);
}

void loop() {
  // Breathing LED on D13 (PWM): 2 breaths.
  for (int b = 0; b < 2; b++) {
    for (int i = 1; i < 255; i += 2) { analogWrite(13, i); delay(4); }
    for (int i = 254; i > 0; i -= 2) { analogWrite(13, i); delay(4); }
  }
  analogWrite(13, 0);
  pinMode(LED_BUILTIN, OUTPUT);
  delay(500);

  int r = runTests();
  analogWrite(12, 0);

  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  if (r == 0) blinks(3, 400, 400);
  else { blinks(10, 60, 60); delay(1200); blinks(r, 400, 400); }
  delay(4000);
}
