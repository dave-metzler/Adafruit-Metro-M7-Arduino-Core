// SPDX-License-Identifier: LGPL-2.1-or-later
// Stage 2 bring-up: UART Serial1 on D0 (RX) / D1 (TX) at 115200 baud.
// Connect a 3.3 V USB-serial adapter: adapter RX -> D1, adapter TX -> D0, GND -> GND.
// (The native USB port is `Serial`; see UsbSerialTest.)  Echoes what you type and blinks D13.

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  Serial1.begin(115200);
  Serial1.println("Metro M7 (RT1011) core says hello");
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last >= 1000) {
    last = millis();
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    Serial1.print("uptime ms: ");
    Serial1.println(millis());
  }
  while (Serial1.available()) {
    Serial1.write(Serial1.read());
  }
}
