// SPDX-License-Identifier: LGPL-2.1-or-later
// attachInterrupt self-test.  One jumper wire: D3 -> D2.
// The sketch drives D3 and watches D2 with interrupts.
//
// Each cycle: LED solid ON 2 s (start marker), then
//   3 slow blinks = all tests passed
//   10 fast blinks = something failed; then N slow blinks tell which test (1..5):
//     1 RISING count wrong   2 FALLING count wrong   3 CHANGE count wrong
//     4 detachInterrupt didn't stop callbacks        5 attachInterruptParam passed the wrong argument
// If you see 1,2,3 all failing, check the wire first (a missing wire gives zero counts).

volatile uint32_t count = 0;
volatile uint32_t seen_param = 0;

void onEdge() { count++; }
void onEdgeParam(void *p) { count++; seen_param = (uint32_t)p; }

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}

// Toggle D3 low->high->low `n` times; returns after settling.
static void pulses(int n) {
  for (int i = 0; i < n; i++) {
    digitalWrite(3, HIGH); delay(2);
    digitalWrite(3, LOW);  delay(2);
  }
}

static int runTests() {
  digitalWrite(3, LOW); delay(5);

  count = 0; attachInterrupt(digitalPinToInterrupt(2), onEdge, RISING);
  pulses(5); delay(5); detachInterrupt(digitalPinToInterrupt(2));
  if (count != 5) return 1;

  count = 0; attachInterrupt(digitalPinToInterrupt(2), onEdge, FALLING);
  pulses(5); delay(5); detachInterrupt(digitalPinToInterrupt(2));
  if (count != 5) return 2;

  count = 0; attachInterrupt(digitalPinToInterrupt(2), onEdge, CHANGE);
  pulses(5); delay(5);
  if (count != 10) return 3;

  detachInterrupt(digitalPinToInterrupt(2));
  count = 0; pulses(5); delay(5);
  if (count != 0) return 4;

  count = 0; seen_param = 0;
  attachInterruptParam(digitalPinToInterrupt(2), onEdgeParam, RISING, (void *)0x1234);
  pulses(3); delay(5); detachInterrupt(digitalPinToInterrupt(2));
  if (count != 3 || seen_param != 0x1234) return 5;
  return 0;
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(2, INPUT);
}

void loop() {
  int r = runTests();
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  if (r == 0) blinks(3, 400, 400);
  else { blinks(10, 60, 60); delay(1200); blinks(r, 400, 400); }
  delay(4000);
}
