// SPDX-License-Identifier: LGPL-2.1-or-later
// Measures the CPU clock and blinks it out on D13.  Read-only: changes no clocks.
//
// Each cycle: LED solid ON 2 s (start marker), pause, then the CPU speed in MHz
// blinked digit by digit (a zero is one tiny flicker), e.g. 500 MHz = 5 blinks,
// zero-flicker, zero-flicker.  Then a 4 s pause and it repeats.
//
// Uses the Cortex-M7 cycle counter (DWT) compared against the 1 MHz timer.

#define DEMCR      (*(volatile uint32_t *)0xE000EDFC)
#define DWT_CTRL   (*(volatile uint32_t *)0xE0001000)
#define DWT_CYCCNT (*(volatile uint32_t *)0xE0001004)

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}

static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

static uint32_t measureMHz() {
  DEMCR |= (1u << 24);        // TRCENA
  DWT_CYCCNT = 0;
  DWT_CTRL |= 1u;             // CYCCNTENA
  uint32_t t0 = micros();
  uint32_t c0 = DWT_CYCCNT;
  while ((uint32_t)(micros() - t0) < 100000u) { }   // 100 ms
  uint32_t cycles = DWT_CYCCNT - c0;
  uint32_t us = micros() - t0;
  return (cycles + us / 2) / us;                    // cycles per us = MHz
}

void setup() { pinMode(LED_BUILTIN, OUTPUT); }

void loop() {
  uint32_t mhz = measureMHz();
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  if (mhz == 0) blinks(10, 60, 60); else blinkDigits(mhz);
  delay(4000);
}
