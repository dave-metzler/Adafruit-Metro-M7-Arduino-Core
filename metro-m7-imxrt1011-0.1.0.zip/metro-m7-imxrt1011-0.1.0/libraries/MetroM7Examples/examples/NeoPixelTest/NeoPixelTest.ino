// SPDX-License-Identifier: LGPL-2.1-or-later
// Cycles the on-board NeoPixel through red, green, blue, white, then a rainbow.
void setup() {
  Serial.begin(115200);
}

static void wheel(uint8_t pos, uint8_t &r, uint8_t &g, uint8_t &b) {
  if (pos < 85)       { r = pos * 3;         g = 255 - pos * 3; b = 0; }
  else if (pos < 170) { pos -= 85;  r = 255 - pos * 3; g = 0;         b = pos * 3; }
  else                { pos -= 170; r = 0;         g = pos * 3;       b = 255 - pos * 3; }
}

void loop() {
  const uint8_t L = 40;   // keep it comfortable to look at
  neopixelWrite(PIN_NEOPIXEL, L, 0, 0); delay(600);
  neopixelWrite(PIN_NEOPIXEL, 0, L, 0); delay(600);
  neopixelWrite(PIN_NEOPIXEL, 0, 0, L); delay(600);
  neopixelWrite(PIN_NEOPIXEL, L, L, L); delay(600);
  for (int i = 0; i < 256; i++) {
    uint8_t r, g, b; wheel(i, r, g, b);
    neopixelWrite(PIN_NEOPIXEL, r * L / 255, g * L / 255, b * L / 255);
    delay(10);
  }
  Serial.println("NeoPixel cycle done");
}
