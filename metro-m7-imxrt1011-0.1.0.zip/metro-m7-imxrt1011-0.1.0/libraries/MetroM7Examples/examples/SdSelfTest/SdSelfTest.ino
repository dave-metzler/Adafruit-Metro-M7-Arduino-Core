// SPDX-License-Identifier: LGPL-2.1-or-later
// SD card self-test for the Metro M7 (microSD socket on LPSPI1, CS = pin 25).
// Insert a FAT16/FAT32 card, flash, open the USB serial monitor (any baud).
// Results are printed every 5 s; the D13 LED also reports:
//   1 blink = SD.begin() failed (no card / wrong format)   2 = write failed
//   3 = read-back mismatch                                  4 = directory/remove failed
//   steady heartbeat = everything passed
#include <SPI.h>
#include <SD.h>

static int  failCode = 0;
static char msg[96];

static void say(const char *s) { Serial.println(s); }

static bool fail(int code, const char *what) {
  failCode = code;
  Serial.print("FAIL: "); Serial.println(what);
  return false;
}

static bool runTests() {
  failCode = 0;
  Serial.println("---- SD self-test ----");
  Serial.print("card detect pin (26): "); pinMode(PIN_SD_CD, INPUT_PULLUP); Serial.println(digitalRead(PIN_SD_CD));
  if (!SD.begin(PIN_SD_CS)) return fail(1, "SD.begin()");
  say("SD.begin OK");

  // 1. small text file
  SD.remove("TEST.TXT");
  File f = SD.open("TEST.TXT", FILE_WRITE);
  if (!f) return fail(2, "open TEST.TXT for write");
  for (int i = 0; i < 200; i++) { f.print("line "); f.println(i); }
  f.close();
  f = SD.open("TEST.TXT");
  if (!f) return fail(3, "reopen TEST.TXT");
  uint32_t size = f.size();
  int lines = 0; char c, prev = 0;
  while (f.available()) { c = f.read(); if (c == '\n') lines++; prev = c; }
  f.close();
  snprintf(msg, sizeof msg, "TEST.TXT size=%lu lines=%d", (unsigned long)size, lines); say(msg);
  if (lines != 200 || prev != '\n') return fail(3, "text readback");

  // 2. append
  f = SD.open("TEST.TXT", FILE_WRITE);
  f.println("appended"); f.close();
  f = SD.open("TEST.TXT");
  if (!f || f.size() <= size) return fail(2, "append");
  f.close();

  // 3. directory + nested file
  SD.mkdir("TESTDIR");
  f = SD.open("TESTDIR/INNER.BIN", FILE_WRITE);
  if (!f) return fail(4, "create file in subdirectory");
  f.write((const uint8_t *)"abc", 3); f.close();
  if (!SD.exists("TESTDIR/INNER.BIN")) return fail(4, "exists() on nested file");

  // 4. listing
  say("root directory:");
  File root = SD.open("/");
  for (File e = root.openNextFile(); e; e = root.openNextFile()) {
    Serial.print("  "); Serial.print(e.name());
    if (e.isDirectory()) Serial.println("/"); else { Serial.print("  "); Serial.println(e.size()); }
    e.close();
  }
  root.close();

  // 5. 256 KiB pattern file: write speed, read speed, verify
  SD.remove("BIG.BIN");
  f = SD.open("BIG.BIN", FILE_WRITE);
  if (!f) return fail(2, "open BIG.BIN");
  static uint8_t buf[512];
  uint32_t t0 = millis();
  for (uint32_t blk = 0; blk < 512; blk++) {
    for (int i = 0; i < 512; i++) buf[i] = (uint8_t)(blk * 7 + i);
    if (f.write(buf, 512) != 512) return fail(2, "write BIG.BIN");
  }
  f.close();
  uint32_t tw = millis() - t0;
  f = SD.open("BIG.BIN");
  if (!f || f.size() != 262144UL) return fail(3, "BIG.BIN size");
  t0 = millis();
  for (uint32_t blk = 0; blk < 512; blk++) {
    if (f.read(buf, 512) != 512) return fail(3, "short read BIG.BIN");
    for (int i = 0; i < 512; i++) if (buf[i] != (uint8_t)(blk * 7 + i)) {
      snprintf(msg, sizeof msg, "mismatch at block %lu byte %d", (unsigned long)blk, i);
      return fail(3, msg);
    }
  }
  uint32_t tr = millis() - t0;
  f.close();
  snprintf(msg, sizeof msg, "256 KiB write %lu ms (%lu KB/s), read %lu ms (%lu KB/s)",
           (unsigned long)tw, (unsigned long)(262144UL / (tw ? tw : 1)),
           (unsigned long)tr, (unsigned long)(262144UL / (tr ? tr : 1)));
  say(msg);

  // 6. cleanup
  SD.remove("TEST.TXT"); SD.remove("BIG.BIN"); SD.remove("TESTDIR/INNER.BIN"); SD.rmdir("TESTDIR");
  if (SD.exists("TEST.TXT") || SD.exists("TESTDIR")) return fail(4, "cleanup");
  say("ALL PASSED");
  return true;
}

static void blinkCode(int n) {
  for (int i = 0; i < n; i++) { digitalWrite(LED_BUILTIN, HIGH); delay(250); digitalWrite(LED_BUILTIN, LOW); delay(250); }
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  // give the host time to open the port, but don't block if nobody does
  for (uint32_t t0 = millis(); !Serial && millis() - t0 < 4000; ) { }
  runTests();
  for (int rep = 0; rep < 5; rep++) {
    if (failCode == 0) { digitalWrite(LED_BUILTIN, HIGH); delay(100); digitalWrite(LED_BUILTIN, LOW); delay(900); }
    else { blinkCode(failCode); delay(1500); }
  }
}
