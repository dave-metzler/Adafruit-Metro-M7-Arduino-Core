// SPDX-License-Identifier: LGPL-2.1-or-later
// Stage 1 bring-up: blink the red D13 LED.  No serial, no USB, nothing else.
// If this blinks once per second, the image is linked at the right address,
// TinyUF2 jumped into it, and startup/GPIO/timing all work.

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);
  delay(500);
  digitalWrite(LED_BUILTIN, LOW);
  delay(500);
}
