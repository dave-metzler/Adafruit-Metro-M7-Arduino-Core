// SPDX-License-Identifier: LGPL-2.1-or-later
// UART self-test with NO serial adapter.  Result is shown on the D13 LED.
//
// Wiring (two jumper wires, board unpowered or not, 3.3 V logic only):
//   D1 (TX)  ->  D0 (RX)     tests transmit + receive + interrupts
//   D1 (TX)  ->  D2          lets the sketch time the bits to check the baud rate
//
// Each cycle: LED solid ON for 2 s (start marker), then
//   Loopback test:  3 slow blinks = PASS,  10 fast blinks = FAIL
//   Baud test:      3 slow blinks = PASS (within 3 %),
//                   1 very long blink = no signal seen on D2 (check the wire),
//                   10 fast blinks = wrong rate; then the measured 9-bit time in
//                   units of 10 us is blinked digit by digit (a zero is one tiny
//                   flicker).  Expected value at 9600 baud: 94  (937.5 us).

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}
static void pass() { blinks(3, 400, 400); }
static void fail() { blinks(10, 60, 60); }

static bool loopbackTest() {
  while (Serial1.available()) Serial1.read();
  for (int i = 0; i < 16; i++) {
    uint8_t b = 0xA0 + i;
    Serial1.write(b);
    unsigned long t = millis();
    while (!Serial1.available() && millis() - t < 50) { }
    if (Serial1.read() != b) return false;
  }
  return true;
}

// Send 0x55 and time the start-bit falling edge to the 9th following edge = 9 bit times.
// Returns microseconds, or 0 if no signal.
static uint32_t measureNineBits() {
  while (Serial1.available()) Serial1.read();
  uint32_t t0 = micros();
  while (!digitalRead(2)) { if (micros() - t0 > 5000) return 0; }  // wait for idle-high
  noInterrupts();
  Serial1.write(0x55);
  t0 = micros();
  while (digitalRead(2)) { if (micros() - t0 > 5000) { interrupts(); return 0; } }
  uint32_t start = micros();
  int level = 0;
  for (int edges = 0; edges < 9; edges++) {
    while (digitalRead(2) == level) { if (micros() - start > 5000) { interrupts(); return 0; } }
    level = !level;
  }
  uint32_t dt = micros() - start;
  interrupts();
  return dt;
}

static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(2, INPUT);
  Serial1.begin(9600);
}

void loop() {
  bool a = loopbackTest();
  uint32_t us = measureNineBits();

  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1000);

  if (a) pass(); else fail();
  delay(1500);

  if (us == 0) { digitalWrite(LED_BUILTIN, HIGH); delay(1500); digitalWrite(LED_BUILTIN, LOW); }
  else if (us > 909 && us < 966) pass();     // 937.5 us +/- 3 %
  else { fail(); delay(1000); blinkDigits((us + 5) / 10); }
  delay(4000);
}
