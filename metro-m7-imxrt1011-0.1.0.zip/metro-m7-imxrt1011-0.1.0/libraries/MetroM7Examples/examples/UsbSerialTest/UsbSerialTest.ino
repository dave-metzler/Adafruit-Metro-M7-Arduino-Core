// SPDX-License-Identifier: LGPL-2.1-or-later
// Native USB Serial test.  Pair with tools/usb_check.py on the computer, or use any terminal.
//
// LED (D13): off = no terminal has the port open; slow blink = port open, waiting;
//            solid = running an echo / generate test.
// Open the port: you get a banner line once a second.  Then send one letter to pick a test
// (the choice resets whenever the port is closed):
//   E  echo: every byte you send comes back unchanged
//   R  receive check: send 65536 bytes (0,1,..255,0,..); the board verifies them itself and
//      replies with one line: RXTEST bytes=.. errors=.. first_err=.. got=.. exp=..
//   0-7  select an experimental controller variant (see usb_set_variant)
//   D  dump controller registers and the log of the first 32 received packets
//   P  same as R but only 4096 bytes (the host sends them slowly, 64 bytes at a time)
//   G  generate: sends exactly 262144 bytes (0,1,2,...255,0,1,...), then returns to the banner
// Banner shows the baud rate the terminal selected (it has no effect on USB speed).

enum Mode { IDLE, ECHO, GEN, RXCHK };
static uint32_t rxCount = 0, rxErr = 0, rxLast = 0;
static int32_t rxFirst = -1; static uint8_t rxGot = 0, rxExp = 0;
static uint32_t RX_TOTAL = 65536;
static Mode mode = IDLE;
static uint32_t genSent = 0;
static const uint32_t GEN_TOTAL = 262144;

// If the board has not been enumerated 12 s after start, the LED reports how far USB got
// (see examples/UsbDiag for the meaning of the digits): stage, SETUPs, resets, errors,
// last bRequest, last wValue high byte.
static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) { digitalWrite(LED_BUILTIN, HIGH); delay(on_ms); digitalWrite(LED_BUILTIN, LOW); delay(off_ms); }
}
static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) { if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250); delay(900); }
  delay(1200);
}
static void usbFailReport() {
  uint32_t f = usb_debug_flags();
  int stage = !(f & USB_DBG_RESET) ? 1 : !(f & USB_DBG_SETUP) ? 2 : !(f & USB_DBG_ADDRESSED) ? 3 : !(f & USB_DBG_CONFIGURED) ? 4 : 5;
  digitalWrite(LED_BUILTIN, HIGH); delay(2000); digitalWrite(LED_BUILTIN, LOW); delay(1500);
  blinkDigits(stage);
  blinkDigits(g_usb_stats[USB_STAT_SETUPS]);
  blinkDigits(g_usb_stats[USB_STAT_RESETS]);
  blinkDigits(g_usb_stats[USB_STAT_UEI]);
  blinkDigits((g_usb_stats[USB_STAT_LAST_REQ] >> 16) & 0xFF);
  blinkDigits((g_usb_stats[USB_STAT_LAST_REQ] >> 8) & 0xFF);
  delay(4000);
}

void setup() { pinMode(LED_BUILTIN, OUTPUT); }

void loop() {
  static uint32_t lastBanner = 0;
  if (!Serial) {                                       // no terminal: reset state, LED off
    mode = IDLE;
    digitalWrite(LED_BUILTIN, LOW);
    if (!(usb_debug_flags() & USB_DBG_CONFIGURED) && millis() > 12000) usbFailReport();
#ifdef RELAXED
    delay(1);
#endif
    return;
  }
  if (mode == IDLE) {
    digitalWrite(LED_BUILTIN, (millis() / 500) & 1);
    if (millis() - lastBanner >= 1000) {
      lastBanner = millis();
      Serial.print("Metro M7 USB serial OK, uptime ms=");
      Serial.print(millis());
      Serial.print(" baud=");
      Serial.println(Serial.baud());
    }
    if (Serial.available()) {
      int c = Serial.read();
      if (c == 'E') mode = ECHO;
      else if (c == 'G') { mode = GEN; genSent = 0; }
      else if (c >= '0' && c <= '7') { usb_set_variant(c - '0'); Serial.print("variant "); Serial.println(c); }
      else if (c == 'D') {
        Serial.print("USBMODE=");  Serial.print(USB_USBMODE, HEX);
        Serial.print(" USBCMD=");  Serial.print(USB_USBCMD, HEX);
        Serial.print(" USBSTS=");  Serial.print(USB_USBSTS, HEX);
        Serial.print(" PORTSC1="); Serial.print(USB_PORTSC1, HEX);
        Serial.print(" ENDPTCTRL2="); Serial.print(USB_ENDPTCTRL2, HEX);
        Serial.print(" SBUSCFG="); Serial.print(USB_SBUSCFG, HEX);
        Serial.print(" BURSTSIZE="); Serial.println(USB_BURSTSIZE, HEX);
        extern volatile uint32_t g_boot_ccr;
        Serial.print("bootCCR="); Serial.print(g_boot_ccr, HEX);
        Serial.print(" CCR="); Serial.println(*(volatile uint32_t *)0xE000ED14, HEX);
        Serial.print("haltclr="); Serial.print(g_usb_stats[USB_STAT_HALTCLR]);
        Serial.print(" uei="); Serial.print(g_usb_stats[USB_STAT_UEI]);
        Serial.print(" resets="); Serial.print(g_usb_stats[USB_STAT_RESETS]);
        Serial.print(" setups="); Serial.print(g_usb_stats[USB_STAT_SETUPS]);
        Serial.print(" lastreq="); Serial.println(g_usb_stats[USB_STAT_LAST_REQ], HEX);
        Serial.print("log count="); Serial.println(g_usb_log_count);
        for (uint32_t i = 0; i < g_usb_log_count && i < USB_LOG_N; i++) {
          Serial.print(i); Serial.print(": tok="); Serial.print(g_usb_log_tok[i], HEX);
          Serial.print(" info="); Serial.print(g_usb_log_info[i], HEX);
          Serial.print(" qh="); Serial.print(g_usb_log_qh[i], HEX);
          Serial.print(" ctl="); Serial.println(g_usb_log_ctl[i], HEX);
        }
        Serial.println("DUMPEND");
      }
      else if (c == 'R' || c == 'P') { usb_diag_reset(); RX_TOTAL = (c == 'R') ? 65536 : 4096; mode = RXCHK; rxCount = rxErr = 0; rxFirst = -1; rxLast = millis(); }
    }
  } else if (mode == ECHO) {
    digitalWrite(LED_BUILTIN, HIGH);
    uint8_t buf[64];
    int n = 0;
    while (n < 64 && Serial.available()) buf[n++] = Serial.read();
    if (n) Serial.write(buf, n);
  } else if (mode == RXCHK) {
    digitalWrite(LED_BUILTIN, HIGH);
    while (Serial.available() && rxCount < RX_TOTAL) {
      uint8_t b = Serial.read(), e = rxCount & 0xFF;
      if (b != e) { if (rxFirst < 0) { rxFirst = rxCount; rxGot = b; rxExp = e; } rxErr++; }
      rxCount++; rxLast = millis();
    }
    if (rxCount >= RX_TOTAL || millis() - rxLast > 3000) {   // done, or stalled for 3 s
      Serial.print("RXTEST bytes="); Serial.print(rxCount);
      Serial.print(" errors=");      Serial.print(rxErr);
      Serial.print(" first_err=");   Serial.print(rxFirst);
      Serial.print(" got=");         Serial.print(rxGot);
      Serial.print(" exp=");         Serial.print(rxExp);
      Serial.print(" rxdone=");      Serial.print(g_usb_stats[USB_STAT_RX_DONE]);
      Serial.print(" rxbytes=");     Serial.print(g_usb_stats[USB_STAT_RX_BYTES]);
      Serial.print(" spurious=");    Serial.print(g_usb_stats[USB_STAT_RX_SPURIOUS]);
      Serial.print(" blocked=");     Serial.print(g_usb_stats[USB_STAT_RX_BLOCKED]);
      Serial.print(" err=");         Serial.println(g_usb_stats[USB_STAT_RX_ERR]);
      Serial.flush();
      mode = IDLE;
    }
  } else {                                             // GEN
    digitalWrite(LED_BUILTIN, HIGH);
    uint8_t buf[64];
    uint32_t n = GEN_TOTAL - genSent;
    if (n > 64) n = 64;
    for (uint32_t i = 0; i < n; i++) buf[i] = (genSent + i) & 0xFF;
    Serial.write(buf, n);
    genSent += n;
    if (genSent >= GEN_TOTAL) { Serial.flush(); mode = IDLE; }
  }
}
