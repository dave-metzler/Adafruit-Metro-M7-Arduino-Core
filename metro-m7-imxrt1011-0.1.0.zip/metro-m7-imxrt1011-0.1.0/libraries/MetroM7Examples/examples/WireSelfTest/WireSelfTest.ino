// SPDX-License-Identifier: LGPL-2.1-or-later
// I2C (Wire) self-test.  Works with NOTHING attached to the SDA/SCL pins or the STEMMA QT
// connector (empty addresses must NACK).  If you do attach an I2C device, it is detected and a
// real read is attempted too.  Result is shown on the D13 LED.
//
// Result cycle: LED solid ON 2 s (start marker), then
//   3 slow blinks = all passed
//   10 fast blinks = failure; then N slow blinks say which test (1..5):
//     1 bus not idle-high before begin (SDA/SCL low: short, or a device holding the bus)
//     2 scan hit an error (code 4) or hung
//     3 timing at 100 kHz wrong     4 timing at 400 kHz wrong
//     5 a device was found but a 1-byte read from it failed
// Then the number of devices found (0 = one tiny flicker), and if any, the first address in
// decimal (e.g. 0x68 = 104), each digit-by-digit.

#include <Wire.h>

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}
static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

static int found = 0;
static int firstAddr = -1;
static int absentAddr = -1;

static int runTests() {
  // 1: both lines high when nobody is driving them (the board has 10k pull-ups)
  Wire.end();
  pinMode(SDA, INPUT); pinMode(SCL, INPUT);
  delay(2);
  if (!digitalRead(SDA) || !digitalRead(SCL)) return 1;

  // 2: scan every legal address
  Wire.begin();
  Wire.setClock(100000);
  found = 0; firstAddr = -1; absentAddr = -1;
  uint32_t t0 = millis();
  for (int a = 0x08; a <= 0x77; a++) {
    Wire.beginTransmission(a);
    uint8_t e = Wire.endTransmission();
    if (e == 0) { found++; if (firstAddr < 0) firstAddr = a; }
    else if (e == 2) { if (absentAddr < 0) absentAddr = a; }
    else return 2;                       // 1/3/4 are not valid for an address-only probe
  }
  if (millis() - t0 > 3000) return 2;
  if (absentAddr < 0) absentAddr = 0x77;  // every address answered?! use one anyway

  // 3/4: time a NACKed probe (START + 9 bits + STOP ~ 11-13 SCL periods)
  const int N = 20;
  Wire.setClock(100000);
  uint32_t us = micros();
  for (int i = 0; i < N; i++) { Wire.beginTransmission(absentAddr); Wire.endTransmission(); }
  uint32_t per = (micros() - us) / N;
  if (per < 100 || per > 180) return 3;

  Wire.setClock(400000);
  us = micros();
  for (int i = 0; i < N; i++) { Wire.beginTransmission(absentAddr); Wire.endTransmission(); }
  per = (micros() - us) / N;
  if (per < 25 || per > 70) return 4;

  // 5: if something answered, read a byte from it
  if (firstAddr >= 0) {
    if (Wire.requestFrom((uint8_t)firstAddr, (size_t)1) != 1 || Wire.available() != 1) return 5;
    Wire.read();
  }
  return 0;
}

void setup() { pinMode(LED_BUILTIN, OUTPUT); }

void loop() {
  int r = runTests();
  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  if (r == 0) blinks(3, 400, 400);
  else { blinks(10, 60, 60); delay(1200); blinks(r, 400, 400); }
  delay(1500);
  blinkDigits(found);
  if (found > 0) { delay(1000); blinkDigits(firstAddr); }
  delay(4000);
}
