// SPDX-License-Identifier: LGPL-2.1-or-later
// analogRead self-test, no equipment beyond a jumper wire.  Result is shown on D13.
//
// Connect pin A0 to GND, or to the 3V3 pin (or a potentiometer wiper between them).
// Each cycle: LED solid ON 2 s (start marker), pause, then the reading as a PERCENTAGE of
// full scale (0..100) blinked digit by digit (a zero is one tiny flicker):
//   A0 on GND  -> 0   (one flicker)
//   A0 on 3V3  -> 100 (one slow blink, then two flickers)
//   A0 floating/unconnected -> some unpredictable value
// To test another pin, change ANALOG_PIN (A0..A5).

#define ANALOG_PIN A0

static void blinks(int n, int on_ms, int off_ms) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_BUILTIN, HIGH); delay(on_ms);
    digitalWrite(LED_BUILTIN, LOW);  delay(off_ms);
  }
}
static void blinkDigits(uint32_t n) {
  char s[12]; int len = 0;
  do { s[len++] = n % 10; n /= 10; } while (n);
  while (len--) {
    if (s[len] == 0) blinks(1, 30, 30); else blinks(s[len], 250, 250);
    delay(900);
  }
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  analogReadResolution(12);
}

void loop() {
  uint32_t sum = 0;
  for (int i = 0; i < 16; i++) sum += analogRead(ANALOG_PIN);
  uint32_t raw = sum / 16;                    // 0..4095
  uint32_t pct = (raw * 100 + 2047) / 4095;   // 0..100

  digitalWrite(LED_BUILTIN, HIGH); delay(2000);
  digitalWrite(LED_BUILTIN, LOW);  delay(1500);
  blinkDigits(pct);
  delay(3000);
}
