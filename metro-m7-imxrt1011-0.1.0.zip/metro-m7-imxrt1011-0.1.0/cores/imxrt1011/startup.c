// SPDX-License-Identifier: LGPL-2.1-or-later
/* Startup code for the Adafruit Metro M7 (i.MX RT1011) behind TinyUF2.
 *
 * Written from scratch against NXP's reference manual / SVD.  Not derived from
 * the Teensy cores.
 *
 * Boot flow: TinyUF2 sets MSP from word 0 of the vector table at 0x6000C000
 * and jumps to the reset vector in word 1.  We therefore must be safe to run
 * with an arbitrary FlexRAM configuration and an arbitrary stack, until
 * Reset_Handler (pure assembly) has configured FlexRAM and loaded a good SP.
 */
#include <stdint.h>
#include <string.h>
#include "imxrt1011.h"

extern uint32_t _estack;
extern uint32_t _sidata, _sdata, _edata, _sbss, _ebss;
extern uint32_t _sfastrunload, _sfastrun, _efastrun;
extern int main(void);
extern void __libc_init_array(void);

void Reset_Handler(void) __attribute__((naked, noreturn, section(".startup")));
void reset_c(void) __attribute__((noreturn, used));
void Default_Handler(void);
void Fault_Handler(void);

/* FlexRAM: we deliberately do NOT reconfigure it.  The bootloader (TinyUF2) runs with the
 * chip's default split -- 32 KB ITCM, 32 KB DTCM, 64 KB OCRAM -- and its USB DMA is known to
 * work in exactly that configuration; our own splits made the USB controller read/write the
 * wrong memory.  See variants/metro_m7/imxrt1011.ld. */

/* Pure-assembly prologue: nothing may touch the stack before SP is valid. */
void Reset_Handler(void)
{
    __asm volatile(
        "cpsid i\n" /* the bootloader may have left IRQs enabled against its own vector table */
        "ldr  r0, =_estack\n"
        "mov  sp, r0\n"
        "bl   reset_c\n"
    );
}

/* ---- ARMv7-M system registers ---- */
#define SCB_VTOR   (*(volatile uint32_t *)0xE000ED08)
#define SCB_CPACR  (*(volatile uint32_t *)0xE000ED88)
#define SCB_SHCSR  (*(volatile uint32_t *)0xE000ED24)

/* RAM copy of the vector table (VTOR needs 512-byte alignment for 96 entries). */
__attribute__((section(".vectorsram"), aligned(512), used))
void (*volatile g_vectors_ram[16 + NUM_IRQ])(void);

/* Disable watchdogs left enabled by earlier boot stages.  Only touches a watchdog
 * that is actually enabled.  WDOG1/2 registers are 16-bit and must be accessed as such. */
static void watchdog_disable(void)
{
    volatile uint16_t *wcr1 = (volatile uint16_t *)WDOG1_WCR_ADDR;
    volatile uint16_t *wcr2 = (volatile uint16_t *)WDOG2_WCR_ADDR;
    if (*wcr1 & (1u << 2)) *wcr1 &= (uint16_t)~(1u << 2); /* WDE */
    if (*wcr2 & (1u << 2)) *wcr2 &= (uint16_t)~(1u << 2);

    if (RTWDOG_CS & (1u << 7)) { /* EN */
        /* Unlock then reconfigure must complete within 128 bus clocks, so the stores
         * are issued back to back from registers.  Layout: CS=+0x0 CNT=+0x4 TOVAL=+0x8.
         * Base register points at CNT. */
        register uint32_t base asm("r0") = RTWDOG_CNT_ADDR;
        register uint32_t cs   asm("r3") = (RTWDOG_CS & ~(1u << 7)) | (1u << 5); /* EN=0, UPDATE=1 */
        register uint32_t tov  asm("r2") = 0xFFFFu;
        if (RTWDOG_CS & (1u << 13)) { /* CMD32EN: one 32-bit unlock word */
            register uint32_t k asm("r1") = 0xD928C520u;
            __asm volatile("str r1,[r0,#0]\n str r2,[r0,#4]\n str r3,[r0,#-4]\n"
                           :: "r"(base), "r"(k), "r"(tov), "r"(cs) : "memory");
        } else {                      /* two 16-bit-style unlock words */
            register uint32_t k  asm("r1") = 0xC520u;
            register uint32_t k2 asm("r12") = 0xD928u;
            __asm volatile("str r1,[r0,#0]\n str r12,[r0,#0]\n str r2,[r0,#4]\n str r3,[r0,#-4]\n"
                           :: "r"(base), "r"(k), "r"(k2), "r"(tov), "r"(cs) : "memory");
        }
    }
}

/* Boot-time CCR, kept for diagnostics.  The D-cache is left as the bootloader set it: disabling
 * it here broke USB enumeration, and the USB driver keeps all DMA structures in DTCM (uncached). */
volatile uint32_t g_boot_ccr;

void reset_c(void)
{
    uint32_t boot_ccr = *(volatile uint32_t *)0xE000ED14;
    /* Quiesce anything the bootloader left running: disable and un-pend every IRQ. */
    for (unsigned i = 0; i < 8; i++) {
        ((volatile uint32_t *)0xE000E180)[i] = 0xFFFFFFFFu; /* ICER */
        ((volatile uint32_t *)0xE000E280)[i] = 0xFFFFFFFFu; /* ICPR */
    }
    watchdog_disable();

    /* Copy hot code to ITCM, initialized data to DTCM, clear .bss */
    uint32_t *src = &_sfastrunload, *dst = &_sfastrun;
    while (dst < &_efastrun) *dst++ = *src++;
    src = &_sidata; dst = &_sdata;
    while (dst < &_edata) *dst++ = *src++;
    for (dst = &_sbss; dst < &_ebss; ) *dst++ = 0;
    g_boot_ccr = boot_ccr;

    /* Enable FPU (CP10/CP11 full access) */
    SCB_CPACR |= (0xFu << 20);
    __asm volatile("dsb\n isb\n");

    /* Move vector table to RAM so drivers can install ISRs at runtime.
     * g_vectors_ram[0] (initial SP) is unused by hardware after reset. */
    extern void (*const g_vectors_flash[16 + NUM_IRQ])(void);
    for (unsigned i = 0; i < 16 + NUM_IRQ; i++)
        g_vectors_ram[i] = g_vectors_flash[i];
    SCB_VTOR = (uint32_t)g_vectors_ram;
    __asm volatile("dsb\n isb\n");

    /* Enable MemManage, BusFault and UsageFault handlers */
    SCB_SHCSR |= (1u << 16) | (1u << 17) | (1u << 18);

    __libc_init_array(); /* C++ static constructors */
    main();
    for (;;) __asm volatile("wfi");
}

void Default_Handler(void) { for (;;) __asm volatile("nop"); }
/* A crash must be visible without a debugger: blink D13 (GPIO_03) rapidly forever.
 * Uses raw registers only; assumes nothing about init() having run. */
void Fault_Handler(void)
{
    CCM_CCGR1 |= (3u << 26);          /* GPIO1 clock on */
    IOMUXC_SW_MUX_CTL_PAD_GPIO_03 = 5; /* ALT5 = GPIO */
    GPIO1_GDIR |= (1u << 3);
    for (;;) {
        GPIO1_DR_TOGGLE = (1u << 3);
        for (volatile uint32_t i = 0; i < 600000; i++) { }
    }
}

/* _init/_fini come from the toolchain's crti.o/crtn.o (.init/.fini are KEEP'd in the linker script). */

/* Flash vector table.  MUST be first in the image: TinyUF2 reads word 0 (SP)
 * and word 1 (reset vector) from 0x6000C000. */
#define IRQ_DEFAULT Default_Handler
__attribute__((section(".isr_vector"), used))
void (*const g_vectors_flash[16 + NUM_IRQ])(void) = {
    (void (*)(void))&_estack, /* 0: initial SP */
    Reset_Handler,            /* 1 */
    Fault_Handler,            /* 2: NMI */
    Fault_Handler,            /* 3: HardFault */
    Fault_Handler,            /* 4: MemManage */
    Fault_Handler,            /* 5: BusFault */
    Fault_Handler,            /* 6: UsageFault */
    0, 0, 0, 0,               /* 7-10 reserved */
    Default_Handler,          /* 11: SVCall */
    Default_Handler,          /* 12: DebugMon */
    0,                        /* 13 reserved */
    Default_Handler,          /* 14: PendSV */
    Default_Handler,          /* 15: SysTick */
    /* IRQs 0..NUM_IRQ-1 */
    [16 ... (16 + NUM_IRQ - 1)] = Default_Handler,
};
