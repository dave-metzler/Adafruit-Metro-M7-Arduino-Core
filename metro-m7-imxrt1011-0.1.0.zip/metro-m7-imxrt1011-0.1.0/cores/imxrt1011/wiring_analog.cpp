// SPDX-License-Identifier: LGPL-2.1-or-later
/* analogRead() on ADC1.
 *
 * ADC1 runs from its own asynchronous clock (ADACK), so it doesn't depend on the bus
 * clock.  12-bit single-ended, reference = VDDA (3.3 V), 8x hardware averaging.
 * ADC channel number == GPIO_AD_nn pad number (see g_pinAdc in the variant).
 */
#include "Arduino.h"

#define CCGR1_ADC1_SHIFT 16
#define CFG_ADICLK_ADACK (3u << 0)
#define CFG_MODE_12BIT   (2u << 2)
#define CFG_ADLSMP       (1u << 4)       /* long sample time: better for high-impedance sources */
#define CFG_ADIV_DIV2    (1u << 5)
#define CFG_AVGS(n)      ((uint32_t)(n) << 14)   /* 0=4, 1=8, 2=16, 3=32 samples */
#define GC_ADACKEN       (1u << 0)
#define GC_AVGE          (1u << 5)
#define GC_CAL           (1u << 7)
#define GS_CALF          (1u << 1)
#define HS_COCO0         (1u << 0)

static bool adc_ready = false;
static int  adc_bits  = 10;

static void adc_setup(void)
{
    CCM_CCGR1 |= (3u << CCGR1_ADC1_SHIFT);

    /* Calibrate with the maximum averaging (as NXP's SDK does), then drop to 8x. */
    ADC1_CFG = CFG_ADICLK_ADACK | CFG_MODE_12BIT | CFG_ADLSMP | CFG_ADIV_DIV2 | CFG_AVGS(3);
    ADC1_GC  = GC_ADACKEN | GC_AVGE;
    ADC1_GC |= GC_CAL;
    uint32_t t0 = micros();
    while ((ADC1_GC & GC_CAL) && (micros() - t0) < 100000u) { }   /* normally a few ms */
    if (ADC1_GS & GS_CALF) ADC1_GS = GS_CALF;                      /* calibration failed: clear and carry on */
    (void)ADC1_R0;                                                 /* discard the calibration result */

    ADC1_CFG = CFG_ADICLK_ADACK | CFG_MODE_12BIT | CFG_ADLSMP | CFG_ADIV_DIV2 | CFG_AVGS(1);
    adc_ready = true;
}

void analogReadResolution(int bits)
{
    if (bits < 1)  bits = 1;
    if (bits > 16) bits = 16;
    adc_bits = bits;
}

void analogReference(uint8_t mode) { (void)mode; }   /* fixed: VDDA (3.3 V) */

int analogRead(pin_size_t pin)
{
    /* Accept A0..A5 constants (14..19) and, as on AVR, plain 0..5 meaning A0..A5. */
    if (pin <= 5) pin += PIN_A0;
    if (pin >= g_pinCount) return 0;
    uint8_t ch = g_pinAdc[pin];
    if (ch == 0xFF) return 0;

    if (!adc_ready) adc_setup();

    /* Analog function: pad as GPIO input with keeper/pull-up/pull-down all off. */
    const PinDescription *p = &g_pinTable[pin];
    *(volatile uint32_t *)p->mux_addr = 5;
    *(volatile uint32_t *)p->pad_addr = 0;

    ADC1_GC &= ~(1u << 6);       /* one-shot, not continuous */
    ADC1_HC0 = ch;               /* writing the channel starts a software-triggered conversion */
    uint32_t t0 = micros();
    while (!(ADC1_HS & HS_COCO0)) { if (micros() - t0 > 10000u) return 0; }
    int raw = (int)(ADC1_R0 & 0xFFFu);

    if (adc_bits < 12) return raw >> (12 - adc_bits);
    if (adc_bits > 12) return raw << (adc_bits - 12);
    return raw;
}
