// SPDX-License-Identifier: LGPL-2.1-or-later
/* Minimal newlib syscall support: just the heap. */
#include <errno.h>
#include <stddef.h>

extern char _heap_start, _heap_end; /* from the linker script */
static char *heap_brk;

void *_sbrk(ptrdiff_t incr)
{
    if (!heap_brk) heap_brk = &_heap_start;
    if (heap_brk + incr > &_heap_end || heap_brk + incr < &_heap_start) {
        errno = ENOMEM;
        return (void *)-1;
    }
    void *prev = heap_brk;
    heap_brk += incr;
    return prev;
}
