// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef UART_H
#define UART_H

#include "api/HardwareSerial.h"

/* Serial1 on LPUART1: RX = D0 (GPIO_09), TX = D1 (GPIO_10).
 * Receive is interrupt driven into a ring buffer; transmit is blocking. */
class Uart : public HardwareSerial {
public:
    Uart() {}                       /* must not touch hardware: runs before init() */
    void begin(unsigned long baud) { begin(baud, SERIAL_8N1); }
    void begin(unsigned long baud, uint16_t config);
    void end();
    int available(void);
    int peek(void);
    int read(void);
    void flush(void);
    size_t write(uint8_t c);
    using Print::write;
    operator bool() { return true; }

    static void isr_trampoline(void);

private:
    static const unsigned RX_SIZE = 256;
    volatile uint8_t rx_buf_[RX_SIZE];
    volatile uint16_t rx_head_ = 0, rx_tail_ = 0;
    void isr();
    friend void lpuart1_isr_entry(void);
};

extern Uart Serial1;

#endif
