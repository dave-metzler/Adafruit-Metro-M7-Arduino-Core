// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef Arduino_h
#define Arduino_h

#include "api/ArduinoAPI.h"
#include "imxrt1011.h"

#ifdef __cplusplus
using namespace arduino;
#endif

#include "pins_arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Pin descriptor table (defined in the variant) ---- */
typedef struct {
    uint32_t mux_addr;   /* IOMUXC_SW_MUX_CTL_PAD_xxx address */
    uint32_t pad_addr;   /* IOMUXC_SW_PAD_CTL_PAD_xxx address */
    uint8_t  gpio;       /* GPIO controller number: 1 or 2 */
    uint8_t  bit;        /* bit within that controller */
} PinDescription;

extern const PinDescription g_pinTable[];
extern const uint8_t g_pinCount;
/* ADC1 channel for each pin (0xFF = pin has no analog function). Indexed like g_pinTable. */
extern const uint8_t g_pinAdc[];

/* FlexPWM1 output for each pin (sm == 0xFF: pin has no PWM). Indexed like g_pinTable. */
typedef struct {
    uint8_t  sm;         /* submodule 0..3 */
    uint8_t  chan;       /* 0 = PWM_A, 1 = PWM_B */
    uint8_t  daisy_val;  /* input-select value for the pad (matches NXP's pin mux data) */
    uint32_t daisy_reg;  /* IOMUXC select-input register address */
} PwmDescription;
extern const PwmDescription g_pinPwm[];

/* ---- NVIC / vector helpers ---- */
extern void (*volatile g_vectors_ram[16 + NUM_IRQ])(void);

static inline void attachInterruptVector(unsigned irq, void (*fn)(void))
{
    g_vectors_ram[16 + irq] = fn;
}
static inline void NVIC_EnableIRQ_(unsigned irq)
{
    *(volatile uint32_t *)(0xE000E100 + 4 * (irq >> 5)) = 1u << (irq & 31);
}
static inline void NVIC_DisableIRQ_(unsigned irq)
{
    *(volatile uint32_t *)(0xE000E180 + 4 * (irq >> 5)) = 1u << (irq & 31);
}
static inline void NVIC_SetPriority_(unsigned irq, uint8_t prio /* 0-255, top 4 bits used */)
{
    *(volatile uint8_t *)(0xE000E400 + irq) = prio;
}

static inline uint32_t irq_disable(void)
{
    uint32_t primask;
    __asm volatile("mrs %0, primask\n cpsid i" : "=r"(primask) :: "memory");
    return primask;
}
static inline void irq_restore(uint32_t primask)
{
    __asm volatile("msr primask, %0" :: "r"(primask) : "memory");
}
static inline void interrupts(void)   { __asm volatile("cpsie i" ::: "memory"); }
static inline void noInterrupts(void) { __asm volatile("cpsid i" ::: "memory"); }

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
/* Drive a WS2812/NeoPixel on `pin` (PIN_NEOPIXEL = the on-board pixel). 0..255 per colour. */
void neopixelWrite(uint8_t pin, uint8_t r, uint8_t g, uint8_t b);
#include "Uart.h"
#include "USBSerial.h"

/* Analog input resolution in bits for analogRead(); default 10 like classic Arduino.
 * Native ADC resolution is 12 bits; values are shifted to the requested width. */
void analogReadResolution(int bits);

/* PWM: analogWrite() on D5, D6, D8..D13.  Default 8-bit duty (0..255) at 4 kHz.
 * Each pair shares one frequency: (D5,D6) (D8,D9) (D10,D11) (D12,D13). */
void analogWriteResolution(int bits);
void analogWriteFrequency(pin_size_t pin, float hz);
/* Measured clock (Hz) feeding the PWM counters; useful for diagnostics. */
uint32_t analogWriteClockHz(void);
#endif

/* attachInterrupt takes a pin number (no separate interrupt numbering on this chip). */
#define digitalPinToInterrupt(p) (p)

#endif /* Arduino_h */
