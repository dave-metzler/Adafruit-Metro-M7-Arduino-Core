// SPDX-License-Identifier: LGPL-2.1-or-later
/* analogWrite() on FlexPWM1 (edge-aligned, independent A/B outputs).
 *
 * Submodule n (0..3) drives two pins (A and B) at one shared frequency.
 * The peripheral clock is measured against the 1 MHz timer on first use, so frequencies
 * are right whatever the bootloader configured.
 *
 * duty 0 / full scale are done as plain GPIO LOW / HIGH (glitch-free, as on other cores).
 */
#include "Arduino.h"

#define PWM_BASE        0x401CC000u
#define SM_STRIDE       0x60u
#define REG16(a)        (*(volatile uint16_t *)(a))
#define SMREG(sm, off)  REG16(PWM_BASE + (sm) * SM_STRIDE + (off))
#define SM_CNT   0x00
#define SM_INIT  0x02
#define SM_CTRL2 0x04
#define SM_CTRL  0x06
#define SM_VAL1  0x0E   /* counter modulus: period - 1 */
#define SM_VAL2  0x12   /* A: set  */
#define SM_VAL3  0x16   /* A: clear */
#define SM_VAL4  0x1A   /* B: set  */
#define SM_VAL5  0x1E   /* B: clear */
#define PWM_OUTEN REG16(PWM_BASE + 0x180)
#define PWM_MCTRL REG16(PWM_BASE + 0x188)
#define PWM_FCTRL0 REG16(PWM_BASE + 0x18C)
#define PWM_FSTS0  REG16(PWM_BASE + 0x18E)
#define SM_DISMAP0 0x2C

#define CTRL_FULL        (1u << 10)
#define CTRL_PRSC(n)     ((uint16_t)(n) << 4)
#define CTRL2_INDEP      (1u << 13)
#define CTRL2_DBGEN      (1u << 15)

#define PAD_PWM_OUT      ((6u << 3) | (2u << 6))   /* DSE 6, speed 2 (same as GPIO outputs) */
#define DEFAULT_FREQ_HZ  4000.0f

static bool     pwm_ready = false;
static uint32_t ipg_hz    = 0;
static int      pwm_bits  = 8;

struct Sm {
    bool     configured;
    uint32_t period;      /* counts per cycle (VAL1 + 1) */
    uint8_t  prsc;
    float    hz;
    uint16_t frac[2];     /* requested duty for A and B, 0..65535 */
};
static Sm sm_state[4];

/* Measure the IPG clock feeding FlexPWM: run a free counter at IPG/128 for ~10 ms. */
static void pwm_measure_ipg(void)
{
    SMREG(0, SM_CTRL2) = 0;
    SMREG(0, SM_INIT)  = 0;
    SMREG(0, SM_VAL1)  = 0xFFFF;
    SMREG(0, SM_CTRL)  = CTRL_FULL | CTRL_PRSC(7);
    PWM_MCTRL |= 1u;                         /* LDOK sm0 */
    PWM_MCTRL |= (1u << 8);                  /* RUN sm0 */
    uint32_t t0 = micros();
    uint16_t c0 = SMREG(0, SM_CNT);
    while ((uint32_t)(micros() - t0) < 10000u) { }
    uint16_t c1 = SMREG(0, SM_CNT);
    uint32_t us = micros() - t0;
    PWM_MCTRL &= ~(1u << 8);                 /* stop */
    uint32_t counts = (uint16_t)(c1 - c0);
    ipg_hz = (uint32_t)(((uint64_t)counts * 128u * 1000000u) / us);
}

static void pwm_init(void)
{
    CCM_CCGR4 |= (3u << 16);                 /* PWM1 clock gate */
    PWM_MCTRL  = 0;
    PWM_OUTEN  = 0;

    /* Fault inputs: at reset FLVL=0 treats a logic-0 on each fault input as a FAULT, and
     * DISMAP=0xFFFF lets every fault input force the outputs off.  The fault inputs are not
     * connected to anything (they read 0), so the outputs would be disabled forever.
     * Make logic-high the fault level (nothing drives it), clear latched flags, and stop the
     * fault inputs from gating any output. */
    PWM_FCTRL0 = (uint16_t)(0xFu << 12);          /* FLVL = 1111 */
    PWM_FSTS0  = 0x000F;                          /* clear FFLAG (write 1 to clear) */
    for (int sm = 0; sm < 4; sm++) SMREG(sm, SM_DISMAP0) = 0;

    pwm_measure_ipg();
    pwm_ready = true;
}

/* Choose prescaler and period for a frequency and program the submodule (not yet running). */
static void sm_set_frequency(int sm, float hz)
{
    if (hz < 1.0f) hz = 1.0f;
    uint8_t prsc = 0; uint32_t period = 0;
    for (prsc = 0; prsc < 8; prsc++) {
        float counts = (float)ipg_hz / ((float)(1u << prsc) * hz);
        if (counts <= 65536.0f) { period = (uint32_t)(counts + 0.5f); break; }
    }
    if (prsc == 8) { prsc = 7; period = 65536; }
    if (period < 2) period = 2;
    Sm &s = sm_state[sm];
    s.prsc = prsc; s.period = period; s.hz = hz;

    SMREG(sm, SM_CTRL2) = CTRL2_INDEP | CTRL2_DBGEN;   /* IPG clock, A and B independent */
    SMREG(sm, SM_INIT)  = 0;
    SMREG(sm, SM_VAL1)  = (uint16_t)(period - 1);
    SMREG(sm, SM_VAL2)  = 0;
    SMREG(sm, SM_VAL4)  = 0;
    SMREG(sm, SM_CTRL)  = CTRL_FULL | CTRL_PRSC(prsc);
    s.configured = true;
}

static void sm_apply_duty(int sm, int chan)
{
    Sm &s = sm_state[sm];
    uint32_t duty = (uint32_t)(((uint64_t)s.frac[chan] * s.period) / 65535u);
    if (duty >= s.period) duty = s.period - 1;
    SMREG(sm, chan ? SM_VAL5 : SM_VAL3) = (uint16_t)duty;
}

static void sm_load_and_run(int sm)
{
    PWM_MCTRL |= (1u << sm);                 /* LDOK: latch the buffered VAL registers */
    PWM_MCTRL |= (1u << (8 + sm));           /* RUN */
}

uint32_t analogWriteClockHz(void)
{
    if (!pwm_ready) pwm_init();
    return ipg_hz;
}

void analogWriteResolution(int bits)
{
    if (bits < 1)  bits = 1;
    if (bits > 16) bits = 16;
    pwm_bits = bits;
}

void analogWriteFrequency(pin_size_t pin, float hz)
{
    if (pin >= g_pinCount || g_pinPwm[pin].sm == 0xFF) return;
    if (!pwm_ready) pwm_init();
    int sm = g_pinPwm[pin].sm;
    sm_set_frequency(sm, hz);
    sm_apply_duty(sm, 0);
    sm_apply_duty(sm, 1);
    sm_load_and_run(sm);
}

void analogWrite(pin_size_t pin, int value)
{
    if (pin >= g_pinCount) return;
    const PwmDescription &d = g_pinPwm[pin];
    int32_t maxv = (1L << pwm_bits) - 1;
    if (value < 0) value = 0;
    if (value > maxv) value = (int)maxv;

    if (d.sm == 0xFF) {                      /* no PWM here: behave like the classic 2-level fallback */
        pinMode(pin, OUTPUT);
        digitalWrite(pin, value >= (maxv + 1) / 2 ? HIGH : LOW);
        return;
    }
    if (value == 0 || value == maxv) {       /* constant levels as plain GPIO */
        pinMode(pin, OUTPUT);
        digitalWrite(pin, value ? HIGH : LOW);
        sm_state[d.sm].frac[d.chan] = value ? 65535 : 0;
        return;
    }

    if (!pwm_ready) pwm_init();
    int sm = d.sm;
    if (!sm_state[sm].configured) {
        sm_state[sm].frac[0] = sm_state[sm].frac[1] = 0;
        sm_set_frequency(sm, DEFAULT_FREQ_HZ);
    }
    sm_state[sm].frac[d.chan] = (uint16_t)(((uint32_t)value * 65535u) / (uint32_t)maxv);
    sm_apply_duty(sm, d.chan);

    const PinDescription &p = g_pinTable[pin];
    *(volatile uint32_t *)d.daisy_reg = d.daisy_val;
    *(volatile uint32_t *)p.mux_addr  = 2;               /* ALT2 = FLEXPWM1_PWMx_A/B */
    *(volatile uint32_t *)p.pad_addr  = PAD_PWM_OUT;
    PWM_OUTEN |= (uint16_t)(1u << ((d.chan ? 4 : 8) + sm));
    sm_load_and_run(sm);
}
