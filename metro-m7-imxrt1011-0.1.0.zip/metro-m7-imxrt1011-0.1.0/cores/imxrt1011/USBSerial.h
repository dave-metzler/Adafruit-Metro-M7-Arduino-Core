// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef USBSERIAL_H
#define USBSERIAL_H

#include "api/HardwareSerial.h"

/* Native USB serial (CDC-ACM) on the board's USB-C connector.
 *
 * `Serial` is this port; the hardware UART on D0/D1 is `Serial1`.
 * The USB device is brought up before setup() runs, so the board enumerates even if the
 * sketch never touches Serial.  Everything is interrupt driven.
 *
 *   while (!Serial) { }     waits for a terminal to open the port (DTR asserted)
 *   Serial.print(...)       never blocks for long: if nobody is reading, data is dropped
 *
 * Opening the port at 1200 baud and then closing it reboots into the TinyUF2 bootloader
 * (same convention as other Arduino boards), so uploads from the IDE need no double-click.
 */
class USBSerial : public HardwareSerial {
public:
    USBSerial() {}                  /* must not touch hardware: runs before init() */
    void begin(unsigned long) {}    /* baud rate is meaningless for USB CDC */
    void begin(unsigned long, uint16_t) {}
    void end() {}
    int available(void);
    int peek(void);
    int read(void);
    void flush(void);               /* waits (bounded) until everything has been sent to the host */
    int availableForWrite(void);
    size_t write(uint8_t c);
    size_t write(const uint8_t *buf, size_t size);
    using Print::write;
    operator bool();                /* true when a host has the port open (configured + DTR) */

    unsigned long baud();           /* line coding most recently set by the host */
    bool dtr();
    bool rts();
};

extern USBSerial Serial;

/* Internal */
void usb_init(void);
/* Bit mask of enumeration progress, for diagnostics (see examples/UsbDiag). */
enum {
    USB_DBG_INIT       = 1u << 0,   /* usb_init() finished */
    USB_DBG_RESET      = 1u << 1,   /* host bus reset seen */
    USB_DBG_SETUP      = 1u << 2,   /* first SETUP packet received */
    USB_DBG_ADDRESSED  = 1u << 3,   /* SET_ADDRESS handled */
    USB_DBG_CONFIGURED = 1u << 4,   /* SET_CONFIGURATION != 0 */
    USB_DBG_DTR        = 1u << 5,   /* terminal opened the port */
    USB_DBG_RX         = 1u << 6,   /* received data from the host */
    USB_DBG_TX         = 1u << 7,   /* a bulk-IN transfer completed */
    USB_DBG_ERROR      = 1u << 8,   /* controller reported a transfer/bus error */
    USB_DBG_PLL_FAIL   = 1u << 9,   /* USB PLL did not lock */
};
uint32_t usb_debug_flags(void);
/* Event counters for diagnostics. */
enum { USB_STAT_ISR, USB_STAT_RX_DONE, USB_STAT_RX_BYTES, USB_STAT_RX_ERR,
       USB_STAT_RX_SPURIOUS, USB_STAT_RX_BLOCKED, USB_STAT_TX_DONE,
       USB_STAT_SETUPS, USB_STAT_RESETS, USB_STAT_UEI, USB_STAT_LAST_REQ /* bmRequestType<<24 | bRequest<<16 | wValue */, USB_STAT_HALTCLR, USB_STAT_USBSTS_LAST,
       USB_STAT_COUNT };
extern volatile uint32_t g_usb_stats[USB_STAT_COUNT];
/* Log of the first USB_LOG_N bulk-OUT completions since usb_diag_reset(): raw dTD token and
 * (bytes | first byte << 8 | ENDPTSTAT << 16). */
#define USB_LOG_N 32
extern volatile uint32_t g_usb_log_tok[USB_LOG_N], g_usb_log_info[USB_LOG_N];
extern volatile uint32_t g_usb_log_count;
extern volatile uint32_t g_usb_log_qh[USB_LOG_N], g_usb_log_ctl[USB_LOG_N];   /* QH overlay token, ENDPTCTRL2 at completion */
void usb_diag_reset(void);
/* Experimental controller settings, applied live (0 = default). */
void usb_set_variant(int v);

#endif
