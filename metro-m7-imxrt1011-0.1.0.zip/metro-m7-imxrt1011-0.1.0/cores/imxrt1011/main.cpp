// SPDX-License-Identifier: LGPL-2.1-or-later
#include "Arduino.h"
#include "USBSerial.h"

void initVariant(void) __attribute__((weak));
void initVariant(void) { }

int main(void)
{
    init();
    usb_init();
    initVariant();
    setup();
    for (;;) {
        loop();
        yield();
    }
    return 0;
}
