// SPDX-License-Identifier: LGPL-2.1-or-later
#include "Arduino.h"

/* LPUART bit definitions (positions verified against the SVD) */
#define STAT_OR     (1u << 19)
#define STAT_RDRF   (1u << 21)
#define STAT_TC     (1u << 22)
#define STAT_TDRE   (1u << 23)
/* write-1-to-clear flags in STAT: MA2F MA1F PF FE NF OR IDLE RXEDGIF LBKDIF */
#define STAT_W1C    ((1u << 14) | (1u << 15) | (1u << 16) | (1u << 17) | (1u << 18) | \
                     (1u << 19) | (1u << 20) | (1u << 30) | (1u << 31))
#define CTRL_PT     (1u << 0)
#define CTRL_PE     (1u << 1)
#define CTRL_M      (1u << 4)
#define CTRL_RE     (1u << 18)
#define CTRL_TE     (1u << 19)
#define CTRL_RIE    (1u << 21)
#define BAUD_SBNS   (1u << 13)
#define BAUD_BOTHEDGE (1u << 17)

#define UART_CLK_HZ 24000000u /* set in init(): CCM_CSCDR1 UART root = 24 MHz crystal */
#define PAD_UART    0x10B0u   /* SDK default for UART pads: DSE=R0/6, speed 150 MHz, keeper */

void lpuart1_isr_entry(void)
{
    Serial1.isr();
}

void Uart::begin(unsigned long baud, uint16_t config)
{
    end();

    /* Pins: GPIO_10 = LPUART1_TXD (ALT0), GPIO_09 = LPUART1_RXD (ALT0).
     * Input daisy selects are the values NXP's SDK pin-mux uses. */
    IOMUXC_SW_MUX_CTL_PAD_GPIO_10 = 0;
    IOMUXC_SW_MUX_CTL_PAD_GPIO_09 = 0;
    IOMUXC_LPUART1_TXD_SELECT_INPUT = 1;
    IOMUXC_LPUART1_RXD_SELECT_INPUT = 1;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_10 = PAD_UART;
    IOMUXC_SW_PAD_CTL_PAD_GPIO_09 = PAD_UART;

    LPUART1_GLOBAL = 2; /* software reset */
    LPUART1_GLOBAL = 0;

    /* Baud: rate = clk / (OSR * SBR), OSR in 4..32.  Pick the least-error pair. */
    uint32_t best_osr = 16, best_sbr = 1;
    uint32_t best_err = 0xFFFFFFFFu;
    for (uint32_t osr = 32; osr >= 4; osr--) {
        uint32_t sbr = (UART_CLK_HZ + (baud * osr) / 2) / (baud * osr);
        if (sbr < 1) sbr = 1;
        if (sbr > 8191) continue;
        uint32_t actual = UART_CLK_HZ / (osr * sbr);
        uint32_t err = actual > baud ? actual - baud : baud - actual;
        if (err < best_err) { best_err = err; best_osr = osr; best_sbr = sbr; }
    }
    uint32_t baudreg = best_sbr | ((best_osr - 1) << 24);
    if (best_osr < 8) baudreg |= BAUD_BOTHEDGE; /* required for OSR 4..7 */
    if ((config & SERIAL_STOP_BIT_MASK) == SERIAL_STOP_BIT_2) baudreg |= BAUD_SBNS;
    LPUART1_BAUD = baudreg;

    uint32_t ctrl = 0;
    uint32_t parity = config & SERIAL_PARITY_MASK;
    uint32_t data = config & SERIAL_DATA_MASK;
    if (parity == SERIAL_PARITY_EVEN || parity == SERIAL_PARITY_ODD) {
        ctrl |= CTRL_PE;
        if (parity == SERIAL_PARITY_ODD) ctrl |= CTRL_PT;
        if (data == SERIAL_DATA_8) ctrl |= CTRL_M; /* 8 data + parity = 9-bit frame */
    }
    /* (7-bit and other data widths are not supported yet: treated as 8 data bits) */

    rx_head_ = rx_tail_ = 0;
    attachInterruptVector(IRQ_LPUART1, lpuart1_isr_entry);
    NVIC_SetPriority_(IRQ_LPUART1, 0x40);
    NVIC_EnableIRQ_(IRQ_LPUART1);

    LPUART1_CTRL = ctrl | CTRL_TE | CTRL_RE | CTRL_RIE;
}

void Uart::end()
{
    LPUART1_CTRL = 0;
    NVIC_DisableIRQ_(IRQ_LPUART1);
}

void Uart::isr()
{
    uint32_t s = LPUART1_STAT;
    if (s & STAT_OR) LPUART1_STAT = (s & ~STAT_W1C) | STAT_OR; /* clear overrun, keep config bits */
    while (LPUART1_STAT & STAT_RDRF) {
        uint8_t c = (uint8_t)LPUART1_DATA;
        uint16_t next = (rx_head_ + 1) % RX_SIZE;
        if (next != rx_tail_) { rx_buf_[rx_head_] = c; rx_head_ = next; } /* drop if full */
    }
}

int Uart::available(void)
{
    return (rx_head_ + RX_SIZE - rx_tail_) % RX_SIZE;
}

int Uart::peek(void)
{
    return rx_head_ == rx_tail_ ? -1 : rx_buf_[rx_tail_];
}

int Uart::read(void)
{
    if (rx_head_ == rx_tail_) return -1;
    uint8_t c = rx_buf_[rx_tail_];
    rx_tail_ = (rx_tail_ + 1) % RX_SIZE;
    return c;
}

size_t Uart::write(uint8_t c)
{
    while (!(LPUART1_STAT & STAT_TDRE)) { }
    LPUART1_DATA = c;
    return 1;
}

void Uart::flush(void)
{
    while (!(LPUART1_STAT & STAT_TC)) { }
}
