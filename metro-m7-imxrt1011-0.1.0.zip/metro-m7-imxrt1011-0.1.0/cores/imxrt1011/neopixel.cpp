// SPDX-License-Identifier: LGPL-2.1-or-later
/* WS2812 / NeoPixel output by cycle-counted bit-banging.
 *
 *   neopixelWrite(PIN_NEOPIXEL, r, g, b);      // the on-board pixel
 *
 * Timing comes from the Cortex-M7 DWT cycle counter, calibrated once against the 1 MHz
 * micros() timer, so it is right at any CPU clock.  Interrupts are masked for the ~30 us a
 * pixel takes (USB tolerates that easily). */
#include "Arduino.h"

#define DEMCR       (*(volatile uint32_t *)0xE000EDFC)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004)
#define DWT_LAR     (*(volatile uint32_t *)0xE0001FB0)

#define GPIO_BASE(n)  ((n) == 1 ? 0x401B8000u : 0x42000000u)
#define GPIO_SET(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x84))
#define GPIO_CLR(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x88))

static uint32_t cyc_per_us;     /* DWT cycles per microsecond (= CPU MHz) */
static uint32_t last_end_us;    /* micros() when the previous frame ended (for the reset gap) */
static bool     used;

static void calibrate(void)
{
    DEMCR |= (1u << 24);        /* TRCENA */
    DWT_LAR = 0xC5ACCE55u;      /* unlock (harmless where not needed) */
    DWT_CTRL |= 1u;             /* CYCCNTENA */
    uint32_t t0 = micros(); while (micros() == t0) { }
    t0 = micros(); uint32_t c0 = DWT_CYCCNT;
    while (micros() - t0 < 200u) { }
    cyc_per_us = (DWT_CYCCNT - c0 + 100u) / 200u;
    if (cyc_per_us < 10u) cyc_per_us = 10u;
}

void neopixelWrite(uint8_t pin, uint8_t r, uint8_t g, uint8_t b)
{
    if (pin >= g_pinCount) return;
    if (!cyc_per_us) calibrate();
    const PinDescription *p = &g_pinTable[pin];
    const uint32_t mask = 1u << p->bit;

    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
    /* >= 80 us low between frames latches the previous one. */
    if (used) while (micros() - last_end_us < 80u) { }

    /* WS2812B: bit period 1.25 us; '0' high 0.35 us, '1' high 0.75 us. */
    const uint32_t period = (cyc_per_us * 125u) / 100u;
    const uint32_t t0h    = (cyc_per_us * 35u) / 100u;
    const uint32_t t1h    = (cyc_per_us * 75u) / 100u;
    const uint32_t grb    = ((uint32_t)g << 16) | ((uint32_t)r << 8) | b;

    uint32_t pm = irq_disable();
    uint32_t start = DWT_CYCCNT;
    for (int i = 23; i >= 0; i--) {
        while (DWT_CYCCNT - start < period) { }     /* wait for the bit slot */
        start = DWT_CYCCNT;
        GPIO_SET(p->gpio) = mask;
        const uint32_t high = (grb >> i) & 1u ? t1h : t0h;
        while (DWT_CYCCNT - start < high) { }
        GPIO_CLR(p->gpio) = mask;
    }
    while (DWT_CYCCNT - start < period) { }
    irq_restore(pm);
    last_end_us = micros();
    used = true;
}
