// SPDX-License-Identifier: LGPL-2.1-or-later
/* USB device controller driver + CDC-ACM serial port for the i.MX RT1011.
 *
 * Written from scratch against the i.MX RT1010 reference manual (ChipIdea / EHCI-style
 * device controller: queue heads + transfer descriptors) and the USB 2.0 / CDC PSTN specs.
 *
 * Design notes
 *  - The port is forced to full speed (12 Mbit/s, 64-byte bulk packets): plenty for a serial
 *    port and it avoids high-speed descriptors and chirp negotiation.
 *  - Each endpoint direction has exactly one transfer descriptor, and a new transfer is only
 *    queued after the previous one completed, so none of the "append to a live queue" races
 *    of the controller are relevant.
 *  - Control transfers are driven from the interrupt handler without blocking.
 *  - No data cache is enabled by this core, so the DMA-visible buffers need no maintenance.
 */
#include "Arduino.h"
#include "USBSerial.h"

#ifndef USB_VID
#define USB_VID 0x1209     /* pid.codes shared test VID/PID: fine for development.  Override  */
#endif
#ifndef USB_PID
#define USB_PID 0x0001     /* with your own allocation (-DUSB_VID=... -DUSB_PID=...) if shipping */
#endif
#ifndef USB_MANUFACTURER
#define USB_MANUFACTURER "Metro M7 Arduino core"
#endif
#ifndef USB_PRODUCT
#define USB_PRODUCT "Metro M7 USB Serial"
#endif

/* ---- register bits (plain numbers; the generated header only has whole registers) ---- */
#define USBCMD_RS      (1u << 0)
#define USBCMD_RST     (1u << 1)
#define USBCMD_SUTW    (1u << 13)
#define USBSTS_UI      (1u << 0)
#define USBSTS_UEI     (1u << 1)
#define USBSTS_PCI     (1u << 2)
#define USBSTS_URI     (1u << 6)
#define USBINTR_UE     (1u << 0)
#define USBINTR_UEE    (1u << 1)
#define USBINTR_URE    (1u << 6)
#define PORTSC_SUSP    (1u << 7)
#define PORTSC_PR      (1u << 8)
#define PORTSC_PFSC    (1u << 24)
#define PHY_SFTRST     (1u << 31)
#define PHY_CLKGATE    (1u << 30)
#define PHY_ENUTMILEVEL2 (1u << 14)
#define PHY_ENUTMILEVEL3 (1u << 15)

/* TinyUF2 (mimxrt10xx port) enters its bootloader when SNVS LPGPR[3] holds this at reset. */
#define TINYUF2_DBL_TAP_MAGIC 0xf01669efu

/* ---- controller data structures (DTCM, like the bootloader's own USB stack) ---- */
struct dQH {                     /* device queue head, 64 bytes */
    volatile uint32_t config;    /* max packet length, ZLT, IOS */
    volatile uint32_t current;
    volatile uint32_t next;
    volatile uint32_t token;
    volatile uint32_t buf[5];
    uint32_t reserved;
    volatile uint32_t setup[2];  /* offset 0x28: SETUP packet lands here */
    uint32_t pad[4];
};
struct dTD {                     /* transfer descriptor, 32 bytes */
    volatile uint32_t next;
    volatile uint32_t token;     /* total bytes [30:16], IOC [15], status [7:0] */
    volatile uint32_t buf[5];
    uint32_t reserved;
};
static_assert(sizeof(dQH) == 64, "dQH size");
static_assert(sizeof(dTD) == 32, "dTD size");

/* Queue head / descriptor index = endpoint * 2 + (1 for IN/TX, 0 for OUT/RX). */
#define EP_RX(n) ((n) * 2)
#define EP_TX(n) ((n) * 2 + 1)
#define EP_BULK       2          /* bulk OUT and IN both use endpoint 2 */
#define EP_NOTIFY     1          /* interrupt IN (CDC notifications, never used) */
#define BULK_MAX      64

static dQH qh[16] __attribute__((aligned(2048)));       /* DTCM: control structures worked reliably here */
static dTD td[16] __attribute__((aligned(32)));

/* ---- buffers ---- */
static uint8_t ep0_buf[128] __attribute__((aligned(32)));  /* control IN data (copied from flash) */
static uint8_t ep0_rx[16]   __attribute__((aligned(32)));  /* control OUT data */
#ifdef RX_OCRAM
static uint8_t rx_pkt[BULK_MAX] __attribute__((aligned(32), section(".ocram")));
static inline void dc_inval(const void *p, unsigned n)
{
    uint32_t a = (uint32_t)p & ~31u, e = (uint32_t)p + n;
    __asm volatile("dsb" ::: "memory");
    for (; a < e; a += 32) *(volatile uint32_t *)0xE000EF5C = a;   /* DCIMVAC */
    __asm volatile("dsb\n isb" ::: "memory");
}
#else
static uint8_t rx_pkt[BULK_MAX] __attribute__((aligned(32)));
static inline void dc_inval(const void *, unsigned) {}
#endif
#define TX_STAGE 512
static uint8_t tx_stage[TX_STAGE] __attribute__((aligned(32)));

#define TX_RING 2048              /* power of two */
#define RX_RING 1024
static volatile uint8_t  tx_ring[TX_RING];
static volatile uint16_t tx_head, tx_tail;
static volatile uint8_t  rx_ring[RX_RING];
static volatile uint16_t rx_head, rx_tail;

/* ---- state ---- */
static volatile uint8_t  usb_config;
static volatile uint8_t  ctrl_line;           /* bit0 DTR, bit1 RTS */
static volatile uint8_t  tx_busy, txdrop, rx_armed;
static volatile uint8_t  pending_set_line, reboot_pending;
static volatile uint32_t dbg;
volatile uint32_t g_usb_stats[USB_STAT_COUNT];
volatile uint32_t g_usb_log_tok[USB_LOG_N], g_usb_log_info[USB_LOG_N];
volatile uint32_t g_usb_log_count;
volatile uint32_t g_usb_log_qh[USB_LOG_N], g_usb_log_ctl[USB_LOG_N];
void usb_diag_reset(void) { g_usb_log_count = 0; for (int i = 0; i <= USB_STAT_TX_DONE; i++) g_usb_stats[i] = 0; }
void usb_set_variant(int v)
{
    USB_USBMODE = (USB_USBMODE & ~(1u << 4)) | (v == 1 ? (1u << 4) : 0);   /* SDIS */
    if (v == 2) USB_SBUSCFG = 1;
    if (v == 3) USB_SBUSCFG = 0;
    if (v == 0) USB_SBUSCFG = 2;
    /* 4: RX toggle inhibit; 5/6: DMA burst sizes; 7: small bursts + RXI.  0-3 restore defaults. */
    if (v != 4 && v != 7) USB_ENDPTCTRL2 &= ~(1u << 5);
    if (v == 4 || v == 7) USB_ENDPTCTRL2 |= (1u << 5);
    if (v <= 4) USB_BURSTSIZE = 0x0808;   /* (v==4 keeps default bursts) */
    if (v == 5 || v == 7) USB_BURSTSIZE = 0x0404;
    if (v == 6) USB_BURSTSIZE = 0x1010;
}
static uint8_t line_coding[7] = { 0x00, 0xC2, 0x01, 0x00, 0x00, 0x00, 0x08 };  /* 115200 8N1 */

struct SetupPkt {
    uint8_t  bmRequestType, bRequest;
    uint16_t wValue, wIndex, wLength;
} __attribute__((packed));
static SetupPkt req;

/* ---- descriptors ---- */
static const uint8_t dev_desc[18] = {
    18, 1, 0x00, 0x02,                  /* bcdUSB 2.00 */
    0xEF, 0x02, 0x01,                   /* Misc / Common / IAD: composite device using an IAD */
    64,                                 /* EP0 max packet */
    USB_VID & 0xFF, USB_VID >> 8, USB_PID & 0xFF, USB_PID >> 8,
    0x00, 0x01,                         /* bcdDevice 1.00 */
    1, 2, 3,                            /* manufacturer, product, serial string indices */
    1                                   /* one configuration */
};

static const uint8_t cfg_desc[75] = {
    9, 2, 75, 0, 2, 1, 0, 0x80, 50,                 /* configuration: 2 interfaces, bus powered, 100 mA */
    8, 0x0B, 0, 2, 0x02, 0x02, 0x00, 0,             /* IAD: interfaces 0-1 are one CDC function */
    9, 4, 0, 0, 1, 0x02, 0x02, 0x00, 0,             /* interface 0: CDC communication, ACM, 1 endpoint */
    5, 0x24, 0x00, 0x10, 0x01,                      /* CDC header, bcdCDC 1.10 */
    5, 0x24, 0x01, 0x00, 0x01,                      /* call management: none, data interface 1 */
    4, 0x24, 0x02, 0x02,                            /* ACM: supports line coding + line state */
    5, 0x24, 0x06, 0x00, 0x01,                      /* union: control 0, subordinate 1 */
    7, 5, 0x80 | EP_NOTIFY, 0x03, 16, 0, 16,        /* notification endpoint (interrupt IN, unused) */
    9, 4, 1, 0, 2, 0x0A, 0x00, 0x00, 0,             /* interface 1: CDC data, 2 endpoints */
    7, 5, EP_BULK, 0x02, BULK_MAX, 0, 0,            /* bulk OUT */
    7, 5, 0x80 | EP_BULK, 0x02, BULK_MAX, 0, 0,     /* bulk IN */
};

static unsigned put_string(uint8_t *out, const char *s)
{
    unsigned n = 2;
    while (*s && n < 62) { out[n++] = (uint8_t)*s++; out[n++] = 0; }
    out[0] = (uint8_t)n; out[1] = 3;
    return n;
}

static unsigned serial_string(uint8_t *out)
{
    /* Unique chip ID (fuse shadow registers) as 16 hex digits: stable across reboots so
     * the host keeps the same port name. */
    char s[17];
    uint32_t id[2] = { OCOTP_HW_OCOTP_CFG0, OCOTP_HW_OCOTP_CFG1 };
    for (int w = 0; w < 2; w++)
        for (int i = 0; i < 8; i++)
            s[w * 8 + i] = "0123456789ABCDEF"[(id[w] >> (28 - 4 * i)) & 0xF];
    s[16] = 0;
    return put_string(out, s);
}

/* ---- low-level transfer helpers ---- */
/* Full barrier: OCRAM sits behind a buffered AXI path, so descriptor/data writes must have
 * *completed* (not just be ordered) before the controller is told to fetch them. */
static inline void dmb(void) { __asm volatile("dsb" ::: "memory"); }

static void ep_queue(unsigned idx, const void *buf, uint32_t len, bool ioc)
{
    dTD *t = &td[idx];
    uint32_t a = (uint32_t)buf;
    t->next  = 1;                                         /* terminate */
    t->token = (len << 16) | (ioc ? (1u << 15) : 0) | 0x80;  /* active */
    t->buf[0] = a;
    for (unsigned i = 1; i < 5; i++) t->buf[i] = (a & ~0xFFFu) + i * 0x1000u;
    qh[idx].next  = (uint32_t)t;
    qh[idx].token &= ~0xFFu;                              /* clear status (active/halted); keep other overlay bits */
    dmb();
    unsigned ep = idx >> 1;
    USB_ENDPTPRIME = (idx & 1) ? (1u << (16 + ep)) : (1u << ep);
}

static inline void ep0_ack(void)  { ep_queue(EP_TX(0), ep0_buf, 0, true); }   /* zero-length IN status */
static inline void ep0_stall(void) { USB_ENDPTCTRL0 |= (1u << 16) | (1u << 0); }

static void ep0_send(const void *data, unsigned len, unsigned want)
{
    if (len > want) len = want;
    if (len > sizeof(ep0_buf)) len = sizeof(ep0_buf);
    if (data != ep0_buf) memcpy(ep0_buf, data, len);
    ep_queue(EP_TX(0), ep0_buf, len, true);
    ep_queue(EP_RX(0), ep0_rx, 0, false);                 /* status stage (host sends zero-length OUT) */
}

static void flush_ep(uint32_t mask)
{
    /* Per the reference manual: wait for any prime in progress, flush, and repeat the flush
     * while the endpoint still reports a buffer ready (a transfer was in flight). */
    for (unsigned attempt = 0; attempt < 16; attempt++) {
        for (unsigned guard = 0; guard < 100000 && (USB_ENDPTPRIME & mask); guard++) { }
        USB_ENDPTFLUSH = mask;
        for (unsigned guard = 0; guard < 100000 && (USB_ENDPTFLUSH & mask); guard++) { }
        if (!(USB_ENDPTSTAT & mask)) break;
    }
}

/* ---- bulk data path ---- */
static inline uint16_t tx_used(void) { return (tx_head - tx_tail) & (TX_RING - 1); }
static inline uint16_t rx_used(void) { return (rx_head - rx_tail) & (RX_RING - 1); }

/* Call with interrupts disabled (or from the ISR). */
static void tx_kick(void)
{
    if (tx_busy || !usb_config) return;
    uint16_t n = tx_used();
    if (n == 0) return;
    if (n > TX_STAGE) n = TX_STAGE;
    uint16_t t = tx_tail;
    for (uint16_t i = 0; i < n; i++) { tx_stage[i] = tx_ring[t]; t = (t + 1) & (TX_RING - 1); }
    tx_tail = t;
    tx_busy = 1;
    ep_queue(EP_TX(EP_BULK), tx_stage, n, true);
}

/* Call with interrupts disabled (or from the ISR). */
static void rx_arm(void)
{
    if (rx_armed || !usb_config) return;
    if (RX_RING - 1 - rx_used() < BULK_MAX) { g_usb_stats[USB_STAT_RX_BLOCKED]++; return; }   /* no room: leave host NAKed until read() */
    rx_armed = 1;
    dc_inval(rx_pkt, BULK_MAX);
    ep_queue(EP_RX(EP_BULK), rx_pkt, BULK_MAX, true);
}

static void bulk_rx_done(void)
{
    uint32_t tok = td[EP_RX(EP_BULK)].token;
    dc_inval(rx_pkt, BULK_MAX);
    g_usb_stats[USB_STAT_RX_DONE]++;
    if (g_usb_log_count < USB_LOG_N) {
        g_usb_log_tok[g_usb_log_count]  = tok;
        g_usb_log_qh[g_usb_log_count]   = qh[EP_RX(EP_BULK)].token;
        g_usb_log_ctl[g_usb_log_count]  = USB_ENDPTCTRL2;
        g_usb_log_info[g_usb_log_count] = (BULK_MAX - ((tok >> 16) & 0x7FFF)) | ((uint32_t)rx_pkt[0] << 8) | ((USB_ENDPTSTAT & 0xFF) << 16);
        g_usb_log_count++;
    }
    if (tok & 0x80) { g_usb_stats[USB_STAT_RX_SPURIOUS]++; return; }   /* transfer still active: not a real completion */
    if (tok & 0x68) { dbg |= USB_DBG_ERROR; g_usb_stats[USB_STAT_RX_ERR]++; }                 /* halted / buffer error / transaction error */
    unsigned n = BULK_MAX - ((tok >> 16) & 0x7FFF);
    if (n > BULK_MAX) n = 0;
    uint16_t h = rx_head;
    for (unsigned i = 0; i < n; i++) { rx_ring[h] = rx_pkt[i]; h = (h + 1) & (RX_RING - 1); }
    rx_head = h;
    g_usb_stats[USB_STAT_RX_BYTES] += n;
    if (n) dbg |= USB_DBG_RX;
    rx_armed = 0;
    rx_arm();
}

static void bulk_tx_done(void)
{
    if (td[EP_TX(EP_BULK)].token & 0x68) dbg |= USB_DBG_ERROR;
    dbg |= USB_DBG_TX;
    g_usb_stats[USB_STAT_TX_DONE]++;
    tx_busy = 0;
    txdrop = 0;
    tx_kick();
}

/* ---- enumeration ---- */
static void configure_endpoints(void)
{
    qh[EP_TX(EP_NOTIFY)].config = (16u << 16);
    /* ZLT=1 (bit 29) *disables* zero-length termination.  Left enabled on an OUT endpoint the
     * controller treats every full-size packet as an unfinished transfer needing a ZLP, and
     * flags the dTD halted + buffer error.  (TinyUSB sets this bit for every endpoint.) */
    qh[EP_RX(EP_BULK)].config   = (BULK_MAX << 16) | (1u << 29);
    qh[EP_TX(EP_BULK)].config   = (BULK_MAX << 16);
    /* TXE | TXR (toggle reset) | type;  type 2 = bulk, 3 = interrupt */
    USB_ENDPTCTRL1 = (1u << 23) | (1u << 22) | (3u << 18);
    USB_ENDPTCTRL2 = (1u << 7) | (1u << 6) | (2u << 2) | (1u << 23) | (1u << 22) | (2u << 18);
    tx_busy = 0; rx_armed = 0; txdrop = 0;
    rx_arm();
    dbg |= USB_DBG_CONFIGURED;
}

static void deconfigure_endpoints(void)
{
    USB_ENDPTCTRL1 = 0;
    USB_ENDPTCTRL2 = 0;
    flush_ep(0xFFFFFFFFu & ~0x00010001u);
    tx_busy = 0; rx_armed = 0;
    tx_head = tx_tail = 0;
}

static void request_reboot_to_bootloader(void)
{
    noInterrupts();
    NVIC_DisableIRQ_(IRQ_USB_OTG1);
    USB_USBCMD &= ~USBCMD_RS;                 /* drop the D+ pull-up and quiesce the controller ... */
    USB_USBCMD |= USBCMD_RST;
    for (uint32_t t0 = micros(); (USB_USBCMD & USBCMD_RST) && micros() - t0 < 5000u; ) { }
    USBPHY_CTRL_SET = PHY_SFTRST | PHY_CLKGATE;   /* ... and put the PHY back in reset so the bootloader starts clean */
    USBPHY_PWD = 0x001E1C00u;
    for (volatile int i = 0; i < 200000; i++) { }  /* let the host notice the disconnect */
    CCM_CCGR5 = 0xFFFFFFFFu;                  /* make sure the SNVS clocks are running */
    SNVS_LPGPR3 = TINYUF2_DBL_TAP_MAGIC;
    dmb();
    for (volatile int i = 0; i < 1000; i++) { }
    *(volatile uint32_t *)0xE000ED0C = 0x05FA0004u;   /* SCB->AIRCR: SYSRESETREQ */
    for (;;) { }
}

static void handle_standard(void)
{
    const unsigned len = req.wLength;
    switch (req.bRequest) {
    case 0x00: {                              /* GET_STATUS */
        static const uint8_t zero2[2] = { 0, 0 };
        ep0_send(zero2, 2, len);
        break;
    }
    case 0x01: case 0x03: {                   /* CLEAR_FEATURE / SET_FEATURE */
        if ((req.bmRequestType & 0x1F) == 2 && req.wValue == 0) {   /* ENDPOINT_HALT */
            unsigned ep = req.wIndex & 0x0F;
            bool in = req.wIndex & 0x80;
            if (ep >= 1 && ep <= 2) {
                volatile uint32_t *ctl = (volatile uint32_t *)(USB_ENDPTCTRL0_ADDR + 4 * ep);
                uint32_t stall = in ? (1u << 16) : (1u << 0), tgl = in ? (1u << 22) : (1u << 6);
                if (req.bRequest == 0x01) g_usb_stats[USB_STAT_HALTCLR]++;
                if (req.bRequest == 0x01) *ctl = (*ctl & ~stall) | tgl;   /* clear halt: also resets the data toggle */
                else                      *ctl |= stall;
            }
        }
        ep0_ack();
        break;
    }
    case 0x05:                                /* SET_ADDRESS: takes effect after the status stage */
        USB_DEVICEADDR = ((uint32_t)(req.wValue & 0x7F) << 25) | (1u << 24);
        dbg |= USB_DBG_ADDRESSED;
        ep0_ack();
        break;
    case 0x06: {                              /* GET_DESCRIPTOR */
        unsigned type = req.wValue >> 8, idx = req.wValue & 0xFF;
        if (type == 1 && idx == 0) {
            ep0_send(dev_desc, sizeof(dev_desc), len);
        } else if (type == 2 && idx == 0) {
            ep0_send(cfg_desc, sizeof(cfg_desc), len);
        } else if (type == 3) {
            uint8_t tmp[64];
            unsigned n = 0;
            if (idx == 0)      { tmp[0] = 4; tmp[1] = 3; tmp[2] = 0x09; tmp[3] = 0x04; n = 4; }
            else if (idx == 1) n = put_string(tmp, USB_MANUFACTURER);
            else if (idx == 2) n = put_string(tmp, USB_PRODUCT);
            else if (idx == 3) n = serial_string(tmp);
            if (n) ep0_send(tmp, n, len); else ep0_stall();
        } else {
            ep0_stall();                      /* device qualifier, BOS, other-speed ...: not supported */
        }
        break;
    }
    case 0x08: {                              /* GET_CONFIGURATION */
        uint8_t c = usb_config;
        ep0_send(&c, 1, len);
        break;
    }
    case 0x09: {                              /* SET_CONFIGURATION */
        unsigned c = req.wValue & 0xFF;
        if (c > 1) { ep0_stall(); break; }
        if (c) {
            usb_config = 1;
            configure_endpoints();
        } else {
            usb_config = 0;
            deconfigure_endpoints();
        }
        ep0_ack();
        break;
    }
    case 0x0A: {                              /* GET_INTERFACE */
        uint8_t z = 0;
        ep0_send(&z, 1, len);
        break;
    }
    case 0x0B:                                /* SET_INTERFACE */
        ep0_ack();
        break;
    default:
        ep0_stall();
    }
}

static void handle_class(void)
{
    switch (req.bRequest) {
    case 0x20:                                /* SET_LINE_CODING: 7 bytes follow in the data stage */
        if (req.wLength == 7) {
            pending_set_line = 1;
            ep_queue(EP_RX(0), ep0_rx, 7, true);
        } else {
            ep0_stall();
        }
        break;
    case 0x21:                                /* GET_LINE_CODING */
        ep0_send(line_coding, 7, req.wLength);
        break;
    case 0x22: {                              /* SET_CONTROL_LINE_STATE */
        uint8_t prev = ctrl_line;
        ctrl_line = req.wValue & 3;
        if (ctrl_line & 1) dbg |= USB_DBG_DTR;
        /* 1200-baud "touch": port closed (DTR dropped) while at 1200 baud -> bootloader.
         * Done after the status stage so the host sees the request succeed. */
        uint32_t baud = line_coding[0] | (line_coding[1] << 8) | (line_coding[2] << 16) | ((uint32_t)line_coding[3] << 24);
        if ((prev & 1) && !(ctrl_line & 1) && baud == 1200) reboot_pending = 1;
        ep0_ack();
        break;
    }
    case 0x23:                                /* SEND_BREAK */
        ep0_ack();
        break;
    default:
        ep0_stall();
    }
}

static void handle_setup(void)
{
    /* Read the SETUP packet without it changing under us (tripwire, per the reference manual). */
    USB_ENDPTSETUPSTAT = 1;
    uint32_t w0, w1;
    do {
        USB_USBCMD |= USBCMD_SUTW;
        w0 = qh[EP_RX(0)].setup[0];
        w1 = qh[EP_RX(0)].setup[1];
    } while (!(USB_USBCMD & USBCMD_SUTW));
    USB_USBCMD &= ~USBCMD_SUTW;
    uint32_t raw[2] = { w0, w1 };
    memcpy(&req, raw, 8);
    dbg |= USB_DBG_SETUP;
    g_usb_stats[USB_STAT_SETUPS]++;
    g_usb_stats[USB_STAT_LAST_REQ] = ((uint32_t)req.bmRequestType << 24) | ((uint32_t)req.bRequest << 16) | req.wValue;

    /* A new SETUP aborts whatever control transfer was in progress. */
    flush_ep(0x00010001u);
    USB_ENDPTCOMPLETE = 0x00010001u;
    pending_set_line = 0;

    switch (req.bmRequestType & 0x60) {
    case 0x00: handle_standard(); break;
    case 0x20: handle_class();    break;
    default:   ep0_stall();       break;
    }
}

static void bus_reset(void)
{
    USB_ENDPTSETUPSTAT = USB_ENDPTSETUPSTAT;
    USB_ENDPTCOMPLETE  = USB_ENDPTCOMPLETE;
    for (unsigned guard = 0; guard < 100000 && USB_ENDPTPRIME; guard++) { }
    USB_ENDPTFLUSH = 0xFFFFFFFFu;
    for (unsigned guard = 0; guard < 100000 && USB_ENDPTFLUSH; guard++) { }
    uint32_t t0 = micros();
    while ((USB_PORTSC1 & PORTSC_PR) && (micros() - t0) < 100000u) { }   /* let the reset finish */

    USB_DEVICEADDR = 0;
    USB_ENDPTCTRL1 = 0;
    USB_ENDPTCTRL2 = 0;
    usb_config = 0; ctrl_line = 0;
    tx_busy = 0; rx_armed = 0; txdrop = 0; pending_set_line = 0; reboot_pending = 0;
    tx_head = tx_tail = 0;
    rx_head = rx_tail = 0;
    dbg |= USB_DBG_RESET;
    g_usb_stats[USB_STAT_RESETS]++;
}

static void usb_isr(void)
{
    g_usb_stats[USB_STAT_ISR]++;
    uint32_t s = USB_USBSTS & (USBINTR_UE | USBINTR_UEE | USBINTR_URE | (1u << 2));
    g_usb_stats[USB_STAT_USBSTS_LAST] = USB_USBSTS;
    USB_USBSTS = s;                                       /* write 1 to clear */
    if (s & USBSTS_UEI) { dbg |= USB_DBG_ERROR; g_usb_stats[USB_STAT_UEI]++; }
    if (s & USBSTS_URI) bus_reset();
    if (s & USBSTS_UI) {
        if (USB_ENDPTSETUPSTAT & 1) handle_setup();
        uint32_t c = USB_ENDPTCOMPLETE;
        if (c) {
            USB_ENDPTCOMPLETE = c;                        /* write 1 to clear */
            if (c & (1u << 0)) {                          /* EP0 OUT complete */
                if (pending_set_line) {
                    pending_set_line = 0;
                    memcpy(line_coding, ep0_rx, 7);
                    ep0_ack();
                }
            }
            if (c & (1u << 16)) {                         /* EP0 IN complete (status of a no-data request) */
                if (reboot_pending) request_reboot_to_bootloader();
            }
            if (c & (1u << EP_BULK))        bulk_rx_done();
            if (c & (1u << (16 + EP_BULK))) bulk_tx_done();
        }
    }
}

uint32_t usb_debug_flags(void) { return dbg; }

void usb_init(void)
{
    CCM_CCGR6 |= 3u;                                      /* usboh3 clock gate on */

    /* USB1 PLL (480 MHz) feeds the PHY.  Bring it up unless the bootloader left it locked. */
    if (!(CCM_ANALOG_PLL_USB1 & (1u << 31)) || !(CCM_ANALOG_PLL_USB1 & (1u << 13))) {
        CCM_ANALOG_PLL_USB1_CLR = 0x3;                    /* DIV_SELECT = 0: 24 MHz x 20 */
        CCM_ANALOG_PLL_USB1_SET = (1u << 12) | (1u << 6) | (1u << 13);   /* POWER | EN_USB_CLKS | ENABLE */
        uint32_t t0 = micros();
        while (!(CCM_ANALOG_PLL_USB1 & (1u << 31))) {
            if (micros() - t0 > 50000u) { dbg |= USB_DBG_PLL_FAIL; break; }
        }
        CCM_ANALOG_PLL_USB1_CLR = (1u << 16);             /* BYPASS off */
    }

    /* Detach and reset anything the bootloader left running, so the host re-enumerates us. */
    USB_USBCMD &= ~USBCMD_RS;
    USBPHY_CTRL_SET = PHY_SFTRST;
    for (volatile int i = 0; i < 2000; i++) { }
    USBPHY_CTRL_CLR = PHY_SFTRST | PHY_CLKGATE;
    USBPHY_PWD = 0;
    USBPHY_CTRL_SET = PHY_ENUTMILEVEL2 | PHY_ENUTMILEVEL3;
    USB_ANALOG_USB1_CHRG_DETECT_SET = (1u << 20) | (1u << 19);   /* EN_B | CHK_CHRG_B: charger detection off */

    USB_USBCMD |= USBCMD_RST;
    for (uint32_t t0 = micros(); (USB_USBCMD & USBCMD_RST) && micros() - t0 < 50000u; ) { }
    USB_USBMODE = 2;                                      /* device mode */

    memset((void *)qh, 0, sizeof(qh));
    memset((void *)td, 0, sizeof(td));
    qh[EP_RX(0)].config = (64u << 16) | (1u << 15);       /* max packet 64, interrupt on SETUP */
    qh[EP_TX(0)].config = (64u << 16);
    for (unsigned i = 0; i < 16; i++) qh[i].next = 1;
    dmb();
    USB_ENDPTLISTADDR = (uint32_t)qh;
    USB_USBCMD &= ~(0xFFu << 16);                         /* interrupt threshold 0: no 1 ms delay */
    USB_PORTSC1 |= PORTSC_PFSC;                           /* full speed only */

    attachInterruptVector(IRQ_USB_OTG1, usb_isr);
    NVIC_SetPriority_(IRQ_USB_OTG1, 0x40);
    USB_USBSTS = 0xFFFFFFFFu;
    USB_USBINTR = USBINTR_UE | USBINTR_UEE | USBINTR_URE;
    NVIC_EnableIRQ_(IRQ_USB_OTG1);

    dbg |= USB_DBG_INIT;
    USB_USBCMD |= USBCMD_RS;                              /* connect: pull-up on D+ */
}

/* ---- Serial API ---- */
int USBSerial::available(void) { return rx_used(); }

int USBSerial::peek(void)
{
    if (rx_head == rx_tail) return -1;
    return rx_ring[rx_tail];
}

int USBSerial::read(void)
{
    if (rx_head == rx_tail) return -1;
    uint8_t c = rx_ring[rx_tail];
    rx_tail = (rx_tail + 1) & (RX_RING - 1);
    if (!rx_armed) {                                      /* reading freed room: let the host send more */
        uint32_t pm = irq_disable();
        rx_arm();
        irq_restore(pm);
    }
    return c;
}

int USBSerial::availableForWrite(void) { return usb_config ? (TX_RING - 1 - tx_used()) : 0; }

size_t USBSerial::write(uint8_t c) { return write(&c, 1); }

size_t USBSerial::write(const uint8_t *p, size_t n)
{
    if (!usb_config) return n;                            /* nobody there: discard, don't block */
    size_t done = 0;
    while (done < n) {
        uint32_t pm = irq_disable();
        size_t room = TX_RING - 1 - tx_used();
        size_t k = (n - done < room) ? (n - done) : room;
        uint16_t h = tx_head;
        for (size_t i = 0; i < k; i++) { tx_ring[h] = p[done + i]; h = (h + 1) & (TX_RING - 1); }
        tx_head = h;
        tx_kick();
        irq_restore(pm);
        done += k;
        if (done < n) {                                   /* ring full: wait briefly for the host to drain it */
            if (txdrop || !usb_config) return n;
            uint32_t t0 = millis();
            while (TX_RING - 1 - tx_used() == 0 && usb_config) {
                if (millis() - t0 > 20) { txdrop = 1; return n; }   /* host not reading: drop until it does */
            }
        }
    }
    return n;
}

void USBSerial::flush(void)
{
    uint32_t t0 = millis();
    while (usb_config && (tx_busy || tx_used())) {
        if (millis() - t0 > 100) break;
    }
}

USBSerial::operator bool() { return usb_config && (ctrl_line & 1) && !(USB_PORTSC1 & PORTSC_SUSP); }

unsigned long USBSerial::baud()
{
    return line_coding[0] | (line_coding[1] << 8) | (line_coding[2] << 16) | ((unsigned long)line_coding[3] << 24);
}
bool USBSerial::dtr() { return ctrl_line & 1; }
bool USBSerial::rts() { return ctrl_line & 2; }
