// SPDX-License-Identifier: LGPL-2.1-or-later
/* Core init and timekeeping.
 *
 * Timekeeping uses GPT1 clocked from the 24 MHz crystal, prescaled to 1 MHz,
 * so micros()/millis()/delay() are correct whatever the CPU clock is.
 */
#include "Arduino.h"

#define CCM_CCG_ON_ALL 3u /* clock on in run and wait mode */

#define GPT_CR_EN       (1u << 0)
#define GPT_CR_CLKSRC24 (5u << 6)   /* 101: crystal oscillator 24 MHz */
#define GPT_CR_FRR      (1u << 9)   /* free-run: don't restart on compare */
#define GPT_CR_EN_24M   (1u << 10)
#define GPT_CR_SWR      (1u << 15)
#define GPT_SR_ROV      (1u << 5)
#define GPT_IR_ROVIE    (1u << 5)

static volatile uint32_t gpt_rollovers; /* high 32 bits of the microsecond count */

static void gpt1_isr(void)
{
    if (GPT1_SR & GPT_SR_ROV) {
        GPT1_SR = GPT_SR_ROV;
        gpt_rollovers++;
    }
}

static uint64_t micros64(void)
{
    uint32_t pm = irq_disable();
    uint32_t lo = GPT1_CNT;
    uint32_t hi = gpt_rollovers;
    /* A rollover may have happened with its ISR still pending (IRQs are off). */
    if ((GPT1_SR & GPT_SR_ROV) && lo < 0x80000000u) hi++;
    irq_restore(pm);
    return ((uint64_t)hi << 32) | lo;
}

void init(void)
{
    /* Peripheral clock gates: GPIO1/2, GPT1 (bus+serial), LPUART1 */
    CCM_CCGR0 |= (CCM_CCG_ON_ALL << 30);                                 /* GPIO2 */
    CCM_CCGR1 |= (CCM_CCG_ON_ALL << 26) | (CCM_CCG_ON_ALL << 20) | (CCM_CCG_ON_ALL << 22); /* GPIO1, GPT1 bus, GPT1 serial */
    CCM_CCGR5 |= (CCM_CCG_ON_ALL << 24);                                 /* LPUART1 */

    CCM_CCGR4 |= (3u << 2) | (3u << 4); /* IOMUXC + IOMUXC_GPR clocks (reset default is on; make sure) */

    /* Use GPIO1 (not the fast GPIO2 mirror) for the multiplexed pads */
    IOMUXC_GPR_GPR26 = 0;

    /* UART clock root = 24 MHz crystal, divide by 1 (independent of CPU clock) */
    CCM_CSCDR1 = (CCM_CSCDR1 & ~((0x3Fu << 0) | (0x3u << 6))) | (1u << 6);

    /* GPT1: 24 MHz / 4 (PRESCALER24M=3) / 6 (PRESCALER=5) = 1 MHz free-running counter */
    GPT1_CR = 0;
    GPT1_CR = GPT_CR_SWR;
    while (GPT1_CR & GPT_CR_SWR) { }
    GPT1_PR = (3u << 12) | 5u;
    GPT1_CR = GPT_CR_EN_24M | GPT_CR_CLKSRC24 | GPT_CR_FRR;
    GPT1_SR = 0x3Fu;
    GPT1_IR = GPT_IR_ROVIE;
    GPT1_CR |= GPT_CR_EN;
    attachInterruptVector(IRQ_GPT1, gpt1_isr);
    NVIC_SetPriority_(IRQ_GPT1, 0x20);
    NVIC_EnableIRQ_(IRQ_GPT1);

    interrupts();
}

unsigned long micros(void) { return GPT1_CNT; }            /* wraps every ~71.6 min, as on AVR */
unsigned long millis(void) { return (unsigned long)(micros64() / 1000u); }

void delayMicroseconds(unsigned int us)
{
    uint32_t start = GPT1_CNT;
    while ((uint32_t)(GPT1_CNT - start) < us) { }
}

void delay(unsigned long ms)
{
    uint32_t start = GPT1_CNT;
    while (ms > 0) {
        yield();
        if ((uint32_t)(GPT1_CNT - start) >= 1000u) {
            start += 1000u;
            ms--;
        }
    }
}

void yield(void) __attribute__((weak));
void yield(void) { }
