// SPDX-License-Identifier: LGPL-2.1-or-later
/* attachInterrupt() on GPIO pins.
 *
 * GPIO1 pads share two combined IRQs (bits 0-15, bits 16-31); GPIO2 (the SD pads D4-D6)
 * has one (bits 0-15).  Each pin has its own callback slot.
 */
#include "Arduino.h"

#define GPIO_BASE(n)   ((n) == 1 ? 0x401B8000u : 0x42000000u)
#define GPIO_ICR1(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x0C))
#define GPIO_ICR2(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x10))
#define GPIO_IMR(n)    (*(volatile uint32_t *)(GPIO_BASE(n) + 0x14))
#define GPIO_ISR(n)    (*(volatile uint32_t *)(GPIO_BASE(n) + 0x18))
#define GPIO_EDGE(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x1C))

struct Slot {
    voidFuncPtr      plain;
    voidFuncPtrParam withParam;
    void            *param;
};
static Slot slots[3][32];          /* index = gpio number (1,2) ; [0] unused */
static bool irqs_installed = false;

static void dispatch(int gpio, uint32_t lo, uint32_t hi)
{
    uint32_t pending = GPIO_ISR(gpio) & GPIO_IMR(gpio);
    for (uint32_t b = lo; b <= hi; b++) {
        if (!(pending & (1u << b))) continue;
        GPIO_ISR(gpio) = (1u << b);                    /* write 1 to clear */
        Slot &s = slots[gpio][b];
        if (s.withParam)  s.withParam(s.param);
        else if (s.plain) s.plain();
    }
}
static void gpio1_lo_isr(void) { dispatch(1, 0, 15); }
static void gpio1_hi_isr(void) { dispatch(1, 16, 31); }
static void gpio2_lo_isr(void) { dispatch(2, 0, 15); }

static void install_irqs(void)
{
    if (irqs_installed) return;
    attachInterruptVector(IRQ_GPIO1_Combined_0_15,  gpio1_lo_isr);
    attachInterruptVector(IRQ_GPIO1_Combined_16_31, gpio1_hi_isr);
    attachInterruptVector(IRQ_GPIO2_Combined_0_15,  gpio2_lo_isr);
    NVIC_SetPriority_(IRQ_GPIO1_Combined_0_15,  0x40);
    NVIC_SetPriority_(IRQ_GPIO1_Combined_16_31, 0x40);
    NVIC_SetPriority_(IRQ_GPIO2_Combined_0_15,  0x40);
    NVIC_EnableIRQ_(IRQ_GPIO1_Combined_0_15);
    NVIC_EnableIRQ_(IRQ_GPIO1_Combined_16_31);
    NVIC_EnableIRQ_(IRQ_GPIO2_Combined_0_15);
    irqs_installed = true;
}

static void configure(pin_size_t pin, voidFuncPtr plain, voidFuncPtrParam withParam, void *param, PinStatus mode)
{
    if (pin >= g_pinCount) return;
    const PinDescription *p = &g_pinTable[pin];
    int g = p->gpio; uint32_t b = p->bit, m = 1u << b;

    uint32_t pm = irq_disable();
    GPIO_IMR(g) &= ~m;                                   /* mask while reconfiguring */
    *(volatile uint32_t *)p->mux_addr = 5;               /* make sure the pad is in GPIO mode */

    /* ICR code: 0 low level, 1 high level, 2 rising edge, 3 falling edge */
    uint32_t icr = 0; bool both = false;
    switch (mode) {
    case LOW:     icr = 0; break;
    case HIGH:    icr = 1; break;
    case RISING:  icr = 2; break;
    case FALLING: icr = 3; break;
    case CHANGE:  both = true; break;
    default:      icr = 2; break;
    }
    volatile uint32_t &reg = (b < 16) ? GPIO_ICR1(g) : GPIO_ICR2(g);
    uint32_t sh = (b & 15u) * 2u;
    reg = (reg & ~(3u << sh)) | (icr << sh);
    if (both) GPIO_EDGE(g) |= m; else GPIO_EDGE(g) &= ~m;

    slots[g][b].plain = plain; slots[g][b].withParam = withParam; slots[g][b].param = param;
    GPIO_ISR(g) = m;                                     /* drop any stale flag */
    GPIO_IMR(g) |= m;
    irq_restore(pm);
    install_irqs();
}

extern "C" {
void attachInterrupt(pin_size_t pin, voidFuncPtr cb, PinStatus mode)
{
    configure(pin, cb, nullptr, nullptr, mode);
}
void attachInterruptParam(pin_size_t pin, voidFuncPtrParam cb, PinStatus mode, void *param)
{
    configure(pin, nullptr, cb, param, mode);
}
void detachInterrupt(pin_size_t pin)
{
    if (pin >= g_pinCount) return;
    const PinDescription *p = &g_pinTable[pin];
    uint32_t pm = irq_disable();
    GPIO_IMR(p->gpio) &= ~(1u << p->bit);
    GPIO_ISR(p->gpio) = (1u << p->bit);
    slots[p->gpio][p->bit] = Slot{nullptr, nullptr, nullptr};
    irq_restore(pm);
}
}
