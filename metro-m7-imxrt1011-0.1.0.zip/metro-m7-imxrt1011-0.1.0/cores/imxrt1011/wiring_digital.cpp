// SPDX-License-Identifier: LGPL-2.1-or-later
/* pinMode / digitalWrite / digitalRead */
#include "Arduino.h"

/* GPIO block: GPIO1 @ 0x401B8000, GPIO2 @ 0x42000000; register offsets from the SVD */
#define GPIO_BASE(n)  ((n) == 1 ? 0x401B8000u : 0x42000000u)
#define GPIO_GDIR(n)  (*(volatile uint32_t *)(GPIO_BASE(n) + 0x04))
#define GPIO_PSR(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x08))
#define GPIO_SET(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x84))
#define GPIO_CLR(n)   (*(volatile uint32_t *)(GPIO_BASE(n) + 0x88))

/* SW_PAD_CTL fields */
#define PAD_DSE(n)  ((uint32_t)(n) << 3)
#define PAD_SPEED(n) ((uint32_t)(n) << 6)
#define PAD_PKE     (1u << 12)
#define PAD_PUE     (1u << 13)
#define PAD_PUS(n)  ((uint32_t)(n) << 14)

#define PAD_OUTPUT   (PAD_DSE(6) | PAD_SPEED(2))
#define PAD_INPUT    (PAD_DSE(0) | PAD_SPEED(2))
#define PAD_PULLUP   (PAD_INPUT | PAD_PKE | PAD_PUE | PAD_PUS(1)) /* 47K pull-up */
#define PAD_PULLDOWN (PAD_INPUT | PAD_PKE | PAD_PUE | PAD_PUS(0)) /* 100K pull-down */
#define PAD_ODE      (1u << 11)

void pinMode(pin_size_t pin, PinMode mode)
{
    if (pin >= g_pinCount) return;
    const PinDescription *p = &g_pinTable[pin];

    *(volatile uint32_t *)p->mux_addr = 5; /* ALT5 = GPIO, SION off */

    uint32_t pad;
    switch (mode) {
    case OUTPUT:         pad = PAD_OUTPUT;   break;
    case OUTPUT_OPENDRAIN: pad = PAD_OUTPUT | PAD_ODE; break;
    case INPUT_PULLUP:   pad = PAD_PULLUP;   break;
    case INPUT_PULLDOWN: pad = PAD_PULLDOWN; break;
    default:             pad = PAD_INPUT;    break; /* INPUT */
    }
    *(volatile uint32_t *)p->pad_addr = pad;

    if (mode == OUTPUT || mode == OUTPUT_OPENDRAIN) GPIO_GDIR(p->gpio) |=  (1u << p->bit);
    else                GPIO_GDIR(p->gpio) &= ~(1u << p->bit);
}

void digitalWrite(pin_size_t pin, PinStatus val)
{
    if (pin >= g_pinCount) return;
    const PinDescription *p = &g_pinTable[pin];
    if (val == LOW) GPIO_CLR(p->gpio) = (1u << p->bit);
    else            GPIO_SET(p->gpio) = (1u << p->bit);
}

PinStatus digitalRead(pin_size_t pin)
{
    if (pin >= g_pinCount) return LOW;
    const PinDescription *p = &g_pinTable[pin];
    return (GPIO_PSR(p->gpio) & (1u << p->bit)) ? HIGH : LOW;
}
